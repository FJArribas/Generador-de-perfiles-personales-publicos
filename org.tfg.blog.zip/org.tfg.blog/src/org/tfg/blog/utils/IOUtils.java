package org.tfg.blog.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IOUtils {

	public static String removeExtension (String s) {

	    String separator = System.getProperty("file.separator");
	    String filename;

	    // Remove the path up to the filename.
	    int lastSeparatorIndex = s.lastIndexOf(separator);
	    if (lastSeparatorIndex == -1) {
	        filename = s;
	    } else {
	        filename = s.substring(lastSeparatorIndex + 1);
	    }

	    // Remove the extension.
	    int extensionIndex = filename.lastIndexOf(".");
	    if (extensionIndex == -1)
	        return filename;

	    return filename.substring(0, extensionIndex);
	}

	// return a list of filenames given a directory
	public static List<String> listFiles (String directory) {
		List<String> result = new ArrayList<>();

	    File path = new File(directory);

	    File [] files = path.listFiles();
	    Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed()); // Sort by last modified

	    for (int i = 0; i < files.length; i++){
	        if (files[i].isFile()) { //this line weeds out other directories/folders
	        	result.add(files[i].getName());
	        }
	    }

	    return result;
	}

	// read a .txt file and return a String with its contents.
    public static String read(String filepath) throws IOException
    {
    	System.out.println(filepath);
        Path fileName = Path.of(filepath);
        String str = Files.readString(fileName);
        return str;
    }

    // convert a String with plain text into a String with .html format
	public static String conversion(String s) {
	    StringBuilder builder = new StringBuilder();
	    boolean flag = false;
	    for (char c : s.toCharArray()) {
	        if (c == ' ') {
	            if (flag == true) {
	                builder.append("&nbsp;");
	                flag = false;
	                continue;
	            }
	            flag = true;
	        } else {
	        	flag = false;
	        }
	        switch (c) {
	            case '<':
	                builder.append("&lt;");
	                break;
	            case '>':
	                builder.append("&gt;");
	                break;
	            case '&':
	                builder.append("&amp;");
	                break;
	            case '"':
	                builder.append("&quot;");
	                break;
	            case '\n':
	                builder.append("<br>");
	                break;
	            case '\t':
	                builder.append("&nbsp; &nbsp; &nbsp;");
	                break;
	            default:
	                builder.append(c);

	        }
	    }
	    String converted = builder.toString();
	    String str = "(?i)\\b((?:https?://|www\\d{0,3}[.]|[a-z0-9.\\-]+[.][a-z]{2,4}/)(?:[^\\s()<>]+|\\(([^\\s()<>]+|(\\([^\\s()<>]+\\)))*\\))+(?:\\(([^\\s()<>]+|(\\([^\\s()<>]+\\)))*\\)|[^\\s`!()\\[\\]{};:\'\".,<>?«»“”‘’]))";
	    Pattern patt = Pattern.compile(str);
	    Matcher matcher = patt.matcher(converted);
	    converted = matcher.replaceAll("<a href=\"$1\">$1</a>");

	    return converted;
	}

	public static List<java.util.Map.Entry<String, String>> massConvert (String directory) {
		java.util.List<java.util.Map.Entry<String, String>> result= new java.util.ArrayList<>();
		List<String> posts = listFiles(directory);
		posts.forEach((post) -> {
			try { // if extension == .html do not convert
				java.util.Map.Entry<String, String> pair=new java.util.AbstractMap.SimpleEntry<>(removeExtension(post), conversion(read(directory + "\\" + post)));
				result.add(pair);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		return result;
	}

    private static void println(String directory) {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args)
    {
    	/* Otra prueba
    	String[] array = new String[] {
    			"texto y una URL http://www.google.com intercalada",
    			"texto y \n\t un cambio de linea con tabulador",
    			"> tercer ejemplo"};
    	Arrays.asList(array).stream().forEach(s -> System.out.println(textToHTML.conversion(s)));
    	*/
    	java.util.List<java.util.Map.Entry<String, String>> result= new java.util.ArrayList<>();
    	List<String> files = new ArrayList<String>();
    	String filepath = "C:\\Users\\EVO\\Desktop\\Prueba";
    	

    	System.out.println ("Files present");
    	files = listFiles (filepath);
    	System.out.println(files);

    	System.out.println ("Reading .txt");
    	files.forEach((file)  -> {
			try {
				System.out.println(read(file));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

    	result = massConvert(filepath);
    	for (Entry<String, String> item : result) {
    	    System.out.println(item);
    	}
    }
}
