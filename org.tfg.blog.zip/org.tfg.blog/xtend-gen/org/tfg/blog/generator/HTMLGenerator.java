package org.tfg.blog.generator;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.tfg.blog.myBlog.AbstractElement;
import org.tfg.blog.myBlog.Entity;
import org.tfg.blog.myBlog.Feature;
import org.tfg.blog.myBlog.PackageDeclaration;
import org.tfg.blog.utils.IOUtils;

@SuppressWarnings("all")
public class HTMLGenerator {
  public CharSequence generateHtmlCode1(final Entity... e) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<!DOCTYPE html>");
    _builder.newLine();
    _builder.append("<html lang=\"en\" >");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<head>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<meta charset=\"UTF-8\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Site"));
      };
      Iterable<Entity> _filter = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function);
      for(final Entity i : _filter) {
        {
          final Function1<Feature, Boolean> _function_1 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "name"));
          };
          Iterable<Feature> _filter_1 = IterableExtensions.<Feature>filter(i.getFeatures(), _function_1);
          for(final Feature f : _filter_1) {
            _builder.append("    \t");
            _builder.append("<title>");
            String _replace = f.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace, "    \t");
            _builder.append("</title>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("    ");
    _builder.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.1.0/css/all.css\" integrity=\"sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt\" crossorigin=\"anonymous\"><link rel=\"stylesheet\" href=\"https://public.codepenassets.com/css/normalize-5.0.0.min.css\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<link rel=\"stylesheet\" href=\"./style.css\">");
    _builder.newLine();
    _builder.append("</head>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<body>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<!-- MAIN CONTAINER -->");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"resume\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<!-- SIDEBAR -->");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<div class=\"base\">");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<div class=\"profile\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<!-- PROFILE PICTURE -->");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<div class=\"photo\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_2 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Sources"));
      };
      Iterable<Entity> _filter_2 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_2);
      for(final Entity i_1 : _filter_2) {
        {
          final Function1<Feature, Boolean> _function_3 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "photo"));
          };
          Iterable<Feature> _filter_3 = IterableExtensions.<Feature>filter(i_1.getFeatures(), _function_3);
          for(final Feature f_1 : _filter_3) {
            _builder.append("                \t");
            _builder.append("<img src=");
            String _replace_1 = f_1.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace_1, "                \t");
            _builder.append(" />");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("                ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<!-- NAME AND OCCUPATION -->");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<div class=\"info\">");
    _builder.newLine();
    _builder.append("                ");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_4 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Site"));
      };
      Iterable<Entity> _filter_4 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_4);
      for(final Entity i_2 : _filter_4) {
        {
          final Function1<Feature, Boolean> _function_5 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "author"));
          };
          Iterable<Feature> _filter_5 = IterableExtensions.<Feature>filter(i_2.getFeatures(), _function_5);
          for(final Feature f_2 : _filter_5) {
            _builder.append("                \t");
            _builder.append("<h1 class=\"name\">");
            String _replace_2 = f_2.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace_2, "                \t");
            _builder.append("</h1>");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          final Function1<Feature, Boolean> _function_6 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "position"));
          };
          Iterable<Feature> _filter_6 = IterableExtensions.<Feature>filter(i_2.getFeatures(), _function_6);
          for(final Feature f_3 : _filter_6) {
            _builder.append("                \t");
            _builder.append("<h1 class=\"name\">");
            String _replace_3 = f_3.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace_3, "                \t");
            _builder.append("</h1>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("                ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<!-- ABOUT ME -->");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<div class=\"about\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_7 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Site"));
      };
      Iterable<Entity> _filter_7 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_7);
      for(final Entity i_3 : _filter_7) {
        {
          final Function1<Feature, Boolean> _function_8 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "bio"));
          };
          Iterable<Feature> _filter_8 = IterableExtensions.<Feature>filter(i_3.getFeatures(), _function_8);
          for(final Feature f_4 : _filter_8) {
            _builder.append("                ");
            _builder.append("<h3>About Me</h3>");
            String _replace_4 = f_4.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace_4, "                ");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("            ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<!-- CONTACT -->");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<div class=\"contact\">");
    _builder.newLine();
    _builder.append("            \t ");
    _builder.append("<h3>Contact Me</h3>");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_9 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Contact"));
      };
      Iterable<Entity> _filter_9 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_9);
      for(final Entity i_4 : _filter_9) {
        {
          EList<Feature> _features = i_4.getFeatures();
          for(final Feature f_5 : _features) {
            _builder.append("<div class=");
            String _name = f_5.getName();
            _builder.append(_name);
            _builder.append("><a href=");
            String _get = f_5.getLiteral().get(0);
            _builder.append(_get);
            _builder.append("><i class=");
            String _get_1 = f_5.getLiteral().get(1);
            _builder.append(_get_1);
            _builder.append("></i><span>");
            String _replace_5 = f_5.getLiteral().get(2).replace("\"", "");
            _builder.append(_replace_5);
            _builder.append("</span></a></div>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("            ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<!-- SOCIALS -->");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<div class=\"follow\">");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<h3>Follow Me</h3>");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<div class=\"box\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_10 = (Entity it) -> {
        String _name_1 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_1, "Socials"));
      };
      Iterable<Entity> _filter_10 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_10);
      for(final Entity i_5 : _filter_10) {
        {
          EList<Feature> _features_1 = i_5.getFeatures();
          for(final Feature f_6 : _features_1) {
            _builder.append("\t\t\t\t");
            _builder.append("<a href=");
            String _get_2 = f_6.getLiteral().get(0);
            _builder.append(_get_2, "\t\t\t\t");
            _builder.append(" target=\"_blank\"><i class=\"fab fa-");
            String _name_1 = f_6.getName();
            _builder.append(_name_1, "\t\t\t\t");
            _builder.append("\"></i></a>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("                ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<!-- MAIN -->");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<div class=\"func\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<!-- MENU -->");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<div class=\"scrollmenu\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_11 = (Entity it) -> {
        String _name_2 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_2, "Menu"));
      };
      Iterable<Entity> _filter_11 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_11);
      for(final Entity i_6 : _filter_11) {
        {
          EList<Feature> _features_2 = i_6.getFeatures();
          for(final Feature f_7 : _features_2) {
            _builder.append("\t\t\t");
            _builder.append("<a href=");
            String _get_3 = f_7.getLiteral().get(0);
            _builder.append(_get_3, "\t\t\t");
            _builder.append(">");
            String _name_2 = f_7.getName();
            _builder.append(_name_2, "\t\t\t");
            _builder.append("</a>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<!-- EDUCATION -->");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<div class=\"edu\" id=\"Education\">");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<h3><i class=\"fa fa-graduation-cap\"></i>Education</h3>");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<ul>");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_12 = (Entity it) -> {
        String _name_3 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_3, "Education"));
      };
      Iterable<Entity> _filter_12 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_12);
      for(final Entity i_7 : _filter_12) {
        {
          EList<Feature> _features_3 = i_7.getFeatures();
          for(final Feature f_8 : _features_3) {
            _builder.append("                            ");
            _builder.append("<li><span>");
            String _replace_6 = f_8.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace_6, "                            ");
            _builder.append("</span><small>");
            String _replace_7 = f_8.getLiteral().get(1).replace("\"", "");
            _builder.append(_replace_7, "                            ");
            _builder.append("</small><small>");
            String _replace_8 = f_8.getLiteral().get(2).replace("\"", "");
            _builder.append(_replace_8, "                            ");
            _builder.append("</small></li>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("                ");
    _builder.append("</ul>");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<!-- EXPERIENCE -->");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<div class=\"work\" id=\"Work\">");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<h3><i class=\"fa fa-briefcase\"></i>Experience</h3>");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<ul>");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_13 = (Entity it) -> {
        String _name_3 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_3, "Experience"));
      };
      Iterable<Entity> _filter_13 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_13);
      for(final Entity i_8 : _filter_13) {
        {
          EList<Feature> _features_4 = i_8.getFeatures();
          for(final Feature f_9 : _features_4) {
            _builder.append("                            ");
            _builder.append("<li><span>");
            String _replace_9 = f_9.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace_9, "                            ");
            _builder.append("</span><small>");
            String _replace_10 = f_9.getLiteral().get(1).replace("\"", "");
            _builder.append(_replace_10, "                            ");
            _builder.append("</small><small>");
            String _replace_11 = f_9.getLiteral().get(2).replace("\"", "");
            _builder.append(_replace_11, "                            ");
            _builder.append("</small></li>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("                ");
    _builder.append("</ul>");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<!-- SKILLS (ALT) -->");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<!-- ");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<div class=\"skills-prog\" id=\"skills-prog\">");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<h3><i class=\"fas fa-code\"></i>Programming Skills</h3>");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<ul>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("<li data-percent=\"95\"><span>HTML5</span>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("<div class=\"skills-bar\">");
    _builder.newLine();
    _builder.append("                            ");
    _builder.append("<div class=\"bar\"></div>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("</li>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("<li data-percent=\"90\"><span>CSS3 & SCSS</span>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("<div class=\"skills-bar\">");
    _builder.newLine();
    _builder.append("                            ");
    _builder.append("<div class=\"bar\"></div>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("</li>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("<li data-percent=\"60\"><span>JavaScript</span>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("<div class=\"skills-bar\">");
    _builder.newLine();
    _builder.append("                            ");
    _builder.append("<div class=\"bar\"></div>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("</li>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("<li data-percent=\"50\"><span>jQuery</span>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("<div class=\"skills-bar\">");
    _builder.newLine();
    _builder.append("                            ");
    _builder.append("<div class=\"bar\"></div>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("</li>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("<li data-percent=\"40\"><span>JSON</span>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("<div class=\"skills-bar\">");
    _builder.newLine();
    _builder.append("                            ");
    _builder.append("<div class=\"bar\"></div>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("</li>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("<li data-percent=\"55\"><span>PHP</span>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("<div class=\"skills-bar\">");
    _builder.newLine();
    _builder.append("                            ");
    _builder.append("<div class=\"bar\"></div>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("</li>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("<li data-percent=\"40\"><span>MySQL</span>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("<div class=\"skills-bar\">");
    _builder.newLine();
    _builder.append("                            ");
    _builder.append("<div class=\"bar\"></div>");
    _builder.newLine();
    _builder.append("                        ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("                    ");
    _builder.append("</li>");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("</ul>");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("-->");
    _builder.newLine();
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<!-- SKILLS -->");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<div class=\"skills-soft\">");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<h3><i class=\"fas fa-bezier-curve\"></i>Software Skills</h3>");
    _builder.newLine();
    _builder.append("                ");
    _builder.append("<ul>");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_14 = (Entity it) -> {
        String _name_3 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_3, "Skills"));
      };
      Iterable<Entity> _filter_14 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_14);
      for(final Entity i_9 : _filter_14) {
        {
          EList<Feature> _features_5 = i_9.getFeatures();
          for(final Feature f_10 : _features_5) {
            _builder.append("\t\t\t\t\t");
            _builder.append("<li data-percent=");
            String _get_4 = f_10.getLiteral().get(1);
            _builder.append(_get_4, "\t\t\t\t\t");
            _builder.append(">");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t\t\t\t");
            _builder.append("\t");
            _builder.append("<svg viewbox=\"0 0 100 100\">");
            _builder.newLine();
            _builder.append("\t\t\t\t\t");
            _builder.append("\t\t");
            _builder.append("<circle cx=\"50\" cy=\"50\" r=\"45\"></circle>");
            _builder.newLine();
            _builder.append("\t\t\t\t\t");
            _builder.append("\t\t");
            _builder.append("<circle class=\"cbar\" cx=\"50\" cy=\"50\" r=\"45\"></circle>");
            _builder.newLine();
            _builder.append("\t\t\t\t\t");
            _builder.append("\t");
            _builder.append("</svg><span>");
            String _get_5 = f_10.getLiteral().get(0);
            _builder.append(_get_5, "\t\t\t\t\t\t");
            _builder.append("</span><small></small>");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t\t\t\t");
            _builder.append("</li>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("                ");
    _builder.append("</ul>");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<!-- INTERESTS -->");
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<div class=\"interests\">");
    _builder.newLine();
    _builder.append("            \t");
    _builder.append("<h3><i class=\"fas fa-star\"></i>Interests</h3>");
    _builder.newLine();
    _builder.append("            \t\t");
    _builder.append("<div class=\"interests-items\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_15 = (Entity it) -> {
        String _name_3 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_3, "Interests"));
      };
      Iterable<Entity> _filter_15 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_15);
      for(final Entity i_10 : _filter_15) {
        {
          EList<Feature> _features_6 = i_10.getFeatures();
          for(final Feature f_11 : _features_6) {
            _builder.append("\t\t\t");
            _builder.append("<div class=\"art\"><i class=");
            String _get_6 = f_11.getLiteral().get(0);
            _builder.append(_get_6, "\t\t\t");
            _builder.append("></i><span style=\"width:130px; word-wrap:break-word; display:inline-block;\">");
            String _name_3 = f_11.getName();
            _builder.append(_name_3, "\t\t\t");
            _builder.append("</span></div>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t\t    \t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("            ");
    _builder.append("<div class=\"interests\">");
    _builder.newLine();
    _builder.append("            \t");
    _builder.append("<h3><i class=\"fas fa-star\"></i>Hobbies</h3>");
    _builder.newLine();
    _builder.append("            \t\t");
    _builder.append("<div class=\"interests-items\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_16 = (Entity it) -> {
        String _name_4 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_4, "Hobbies"));
      };
      Iterable<Entity> _filter_16 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_16);
      for(final Entity i_11 : _filter_16) {
        {
          EList<Feature> _features_7 = i_11.getFeatures();
          for(final Feature f_12 : _features_7) {
            _builder.append("\t\t\t");
            _builder.append("<div class=\"art\"><i class=");
            String _get_7 = f_12.getLiteral().get(0);
            _builder.append(_get_7, "\t\t\t");
            _builder.append("></i><span style=\"width:130px; word-wrap:break-word; display:inline-block;\">");
            String _name_4 = f_12.getName();
            _builder.append(_name_4, "\t\t\t");
            _builder.append("</span></div>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t\t    \t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<!-- BLOG POSTS -->");
    _builder.newLine();
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_17 = (Entity it) -> {
        String _name_5 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_5, "Sources"));
      };
      Iterable<Entity> _filter_17 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_17);
      for(final Entity i_12 : _filter_17) {
        {
          final Function1<Feature, Boolean> _function_18 = (Feature it) -> {
            String _name_5 = it.getName();
            return Boolean.valueOf(Objects.equals(_name_5, "posts"));
          };
          Iterable<Feature> _filter_18 = IterableExtensions.<Feature>filter(i_12.getFeatures(), _function_18);
          for(final Feature f_13 : _filter_18) {
            {
              List<Map.Entry<String, String>> _massConvert = IOUtils.massConvert(f_13.getLiteral().get(0).replace("\"", ""));
              for(final Map.Entry<String, String> p : _massConvert) {
                _builder.append("<div class=\"blog\">");
                _builder.newLine();
                _builder.append("<h3><i class=\"fas fa-star\"></i>");
                String _key = p.getKey();
                _builder.append(_key);
                _builder.append("</h3>");
                _builder.newLineIfNotEmpty();
                _builder.append("\t\t\t\t\t    \t");
                String _value = p.getValue();
                _builder.append(_value, "\t\t\t\t\t    \t");
                _builder.newLineIfNotEmpty();
                _builder.append("</div>");
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.append("        ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<!-- partial -->");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<script src=\'https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js\'></script><script    src=\"./script.js\"></script>");
    _builder.newLine();
    _builder.append("</body>");
    _builder.newLine();
    _builder.append("</html>");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }

  public CharSequence generateHtmlCode2(final Entity... e) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<!DOCTYPE html>");
    _builder.newLine();
    _builder.append("<html lang=\"en\" >");
    _builder.newLine();
    _builder.append("<head>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<meta charset=\"UTF-8\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<title>Responsive Resume</title>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<link rel=\'stylesheet\' href=\'https://fonts.googleapis.com/css?family=Playfair+Display|PT+Sans\'>");
    _builder.newLine();
    _builder.append("<link rel=\'stylesheet\' href=\'https://s3-us-west-2.amazonaws.com/s.cdpn.io/85807/font-awesome.css\'>");
    _builder.newLine();
    _builder.append("<link rel=\'stylesheet\' href=\'https://fonts.googleapis.com/css?family=Montserrat:400, 700\'><link rel=\"stylesheet\" href=\"./style.css\">");
    _builder.newLine();
    _builder.newLine();
    _builder.newLine();
    _builder.newLine();
    _builder.append("</head>");
    _builder.newLine();
    _builder.append("<body>");
    _builder.newLine();
    _builder.append("<!-- partial:index.partial.html -->");
    _builder.newLine();
    _builder.append("<div class=\"contOut clearfix\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<div class=\"contIn\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"section top clearfix\">");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"logoCont\"><img class=\"logo\" src=\"..\\static\\pfp.jpg\"/></div>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<h1>Pablo Gómez-Abajo</h1>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"moreInfo\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<p>CS Dept., UAM, Spain<br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<a href=\"mailto:pablo.gomeza@uam.es\" target=\"_blank\">pablo.gomeza@uam.es</a><br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("+34 91 497 2358<br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<a href=\"https://gomezabajo.github.io/\" target=\"_blank\">gomezabajo.github.io</a></p>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<p class=\"tagline\">Assistant Professor<br/>PhD<br/><span>Eclipse Development</span></p>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"divider\"></div>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("<div class=\"contOut clearfix\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<div class=\"contIn\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"section middle clearfix\">");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"job\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<h2>Stab Vida<span>October, 2005 </span></h2>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<p><strong>Position: </strong>IT Technician<br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<strong>Description: </strong>I manage the entire process of website design and development for projects varying in scope.<br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<span class=\"brag\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</span></p>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"divider\"></div>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("<div class=\"contOut clearfix\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<div class=\"contIn\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"section middle clearfix\">");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"job\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<h2>Hewlett-Packard<span>June, 2006-September, 2006 </span></h2>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<p><strong>Position: </strong>IT Technician - Human Resources Department<br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<strong>Description: </strong>Website & Software development, design, UI and project management<br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<span class=\"brag\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</span></p>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"divider\"></div>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("<div class=\"contOut clearfix\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<div class=\"contIn\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"section middle clearfix\">");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"job\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<h2>Prefabricados Castelo<span>February, 2008-July, 2008 </span></h2>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<p><strong>Position: </strong>IT Technician<br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<strong>Description: </strong>Maintain internal database, administration, project management, team building<br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<span class=\"brag\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</span></p>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"divider\"></div>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("<div class=\"contOut clearfix\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<div class=\"contIn\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"section middle clearfix\">");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"job\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<h2>Ingeniería y Prevención de Riesgos, S.L.<span>July, 2008-March, 2015 </span></h2>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<p><strong>Position: </strong>IT Manager<br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<strong>Description: </strong>Logistical database modeling for transportation battalion\'s convoy movements<br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<span class=\"brag\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</span></p>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"divider\"></div>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("<div class=\"contOut clearfix\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<div class=\"contIn\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"section middle clearfix\">");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"job\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<h2>Universidad Autónoma de Madrid<span>March, 2015-Today </span></h2>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<p><strong>Position: </strong>Researcher<br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<strong>Description: </strong>Logistical database modeling for transportation battalion\'s convoy movements<br/>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<span class=\"brag\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</span></p>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"divider\"></div>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<div class=\"contOut clearfix half\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<div class=\"contIn\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"section middle clearfix\">");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"skills code odd\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<h3>Code & Software<i class=\"fa fa-code\"></i></h3>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<ul>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">JavaScript</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>jQuery</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>jQuery UI</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Angular</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>AJAX</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">CSS</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>CSS3</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Sass</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Scss</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Compass</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"light\">Bourbon</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">HTML</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>HMTL5</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>xhtml</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Jade</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"light\">Haml</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"light\">SVG</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">Database</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"light\">Ruby</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Ruby on Rails</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>ASP</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>PHP</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"light\">PostgreSQL</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"light\">MySQL</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">Platforms</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>RapidWeaver</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Wix</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>WordPress</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Ghost</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"light\">Tumblr</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"light\">Joomla</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">API</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Google Maps</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Google Places</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Facebook</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Pinterest</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Instagram</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"light\">PayPal</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">Frameworks</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Bootstrap</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Foundation</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Pure</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">Editors</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Aptana</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Brackets</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Sublime Text</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Codepen</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>jsFiddle</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Plist Editor Pro</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">Environments</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Git</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>BitBucket</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>GitHub</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>WAMP/MAMP</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">Graphics</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Photoshop</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Illustrator</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"light\">After Effects</li>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("</ul>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"skills software\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<h3>Practices & Tools<i class=\"fa fa-laptop\"></i></h3>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<ul>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">Markup</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Semantic/intuitive</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Unintrusive</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Uniform Indention</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Sparingly Complex</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Browser Compliance</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Validated</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>SEO Compliant</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">Design</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Responsive</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Single Page Apps</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>MVC Frameworks</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>UI & UX</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Branding</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>A/B Testing</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Pixel Perfect</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Cross-browser</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Touch Friendly</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Retina Ready</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Fast</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">Dev Approach</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Plan</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Modular Builds</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Version Control</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Test</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Debug</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">Troubleshooting</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>StackOverflow</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Chrome Dev Tools</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">Project Management</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Asana</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Jira</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Hipchat</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Basecamp</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Slack</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li class=\"prim\">Site Optimization</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Google Analytics</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Webmaster/Console Tools</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>Website Insight</li>");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("<li>PageSpeed</li>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("</ul>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"divider\"></div>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("<div class=\"contOut clearfix\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<div class=\"contIn\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"contracts clearfix\">");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<h3>Contract Employers</h3>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"contract\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<h4>Internet Marketing Bar</h4>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<p class=\"desc\">User Interface (UI) design, custom WP Admin design, custom WP theme design, Dashboard & <a href=\"https://codepen.io/jhawes/pen/gbPrbZ\" target=\"_blank\">Email Mktg dashboard </a>design.</p><span class=\"date\">2014</span>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"contract\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<h4>Iron Post Media</h4>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<p class=\"desc\">Custom WP theme changes & custom <a href=\"https://codepen.io/jhawes/pen/ujdgK\" target=\"_blank\">Google Maps polygon coordinate tool </a>used for real estate <a href=\"https://codepen.io/jhawes/pen/wBACp\" target=\"_blank\">drill-down navigation </a>design.</p><span class=\"date\">2014</span>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"contract\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<h4>California Crane School</h4>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<p class=\"desc\">Various custom PHP & WP projects: <a href=\"http://californiacraneschool.com\" target=\"_blank\">CaliforniaCraneSchool.com</a>, <a href=\"http://craneaccidents.com\" target=\"_blank\">CraneAccidents.com</a>, <a href=\"http://cranehunter.com\" target=\"_blank\">CraneHunter.org</a>, and more to come.</p><span class=\"date\">2011 - 2014</span>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<div class=\"contract\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<h4>SMUD</h4>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<p class=\"desc\">");
    _builder.newLine();
    _builder.append("           ");
    _builder.append("Additions & changes to various DOM elements & stylesheets within company portal.<span class=\"date\">2010</span></p>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("<div class=\"contOut clearfix half\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<div class=\"contIn\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"section middle clearfix\">");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<ul class=\"buttons\">");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<li><a href=\"http://onelittledesigner.com\" target=\"_blank\">1LittleDesigner.com</a></li>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<li><a href=\"http://rapidweaverebook.com\" target=\"_blank\">RapidWeaverEbook.com</a></li>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<li><a href=\"http://pure4rw.com\" target=\"_blank\">Pure4RW.com</a></li>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<li><a href=\"http://hashtaghawes.com\" target=\"_blank\">HashtagHawes.com</a></li>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<li><a href=\"http://papertemple.net\" target=\"_blank\">PaperTemple.net</a></li>");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("<li><a href=\"http://coffeetablestudios.com\" target=\"_blank\">CoffeeTableStudios.com</a></li>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("</ul>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<div class=\"divider\"></div>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("<ul class=\"sm\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<li><a href=\"https://codepen.io/jhawes/\"><i class=\"fa fa-codepen\"></i></a></li>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<li><a href=\"https://twitter.com/jeremyhawes\"><i class=\"fa fa-twitter\"></i></a></li>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<li><a href=\"https://www.facebook.com/1LittleDesigner\"><i class=\"fa fa-facebook\"></i></a></li>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<li><a href=\"https://plus.google.com/+JeremyHawes/posts\"><i class=\"fa fa-google-plus\"></i></a></li>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<li><a href=\"https://www.flickr.com/photos/artbyhawes/\"><i class=\"fa fa-flickr\"></i></a></li>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<li><a href=\"http://instagram.com/haweshead/\"><i class=\"fa fa-instagram\"></i></a></li>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<li><a href=\"https://www.linkedin.com/in/jeremyhawes\"><i class=\"fa fa-linkedin\"></i></a></li>");
    _builder.newLine();
    _builder.append("</ul>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<!-- partial -->");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<script src=\'//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js\'></script><script type=\"text/javascript\"  src=\"./script.js\"></script>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("</body>");
    _builder.newLine();
    _builder.append("</html>");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }

  public CharSequence generateHtmlCode3Index(final PackageDeclaration p) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<link rel=\"stylesheet\" href=\"./style.css\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<div class=\"row\">");
    _builder.newLine();
    {
      EList<AbstractElement> _elements = p.getElements();
      for(final AbstractElement user : _elements) {
        {
          if ((user instanceof Entity)) {
            _builder.append("\t");
            _builder.append("<div class=\"column\">");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("<div class=\"card\">");
            _builder.newLine();
            {
              final Function1<Feature, Boolean> _function = (Feature it) -> {
                String _name = it.getName();
                return Boolean.valueOf(Objects.equals(_name, "id"));
              };
              Iterable<Feature> _filter = IterableExtensions.<Feature>filter(((Entity)user).getFeatures(), _function);
              for(final Feature f : _filter) {
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("<a href=\"users\\");
                String _replace = f.getLiteral().get(0).replace("\"", "");
                _builder.append(_replace, "\t\t");
                _builder.append(".html\">");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("<img src=\"..\\static\\");
                String _replace_1 = f.getLiteral().get(0).replace("\"", "");
                _builder.append(_replace_1, "\t\t\t");
                _builder.append(".png\" alt=");
                String _get = f.getLiteral().get(0);
                _builder.append(_get, "\t\t\t");
                _builder.append(" style=\"width:100%\">");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("</a>");
                _builder.newLine();
              }
            }
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("<div class=\"container\">");
            _builder.newLine();
            {
              final Function1<Feature, Boolean> _function_1 = (Feature it) -> {
                String _name = it.getName();
                return Boolean.valueOf(Objects.equals(_name, "name"));
              };
              Iterable<Feature> _filter_1 = IterableExtensions.<Feature>filter(((Entity)user).getFeatures(), _function_1);
              for(final Feature f_1 : _filter_1) {
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("<h2>");
                String _replace_2 = f_1.getLiteral().get(0).replace("\"", "");
                _builder.append(_replace_2, "\t\t");
                _builder.append("</h2>");
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append("\t");
            _builder.append("\t        ");
            _builder.append("<p class=\"title\">CEO &amp; Founder</p>");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("\t        ");
            _builder.append("<p>Some text that describes me lorem ipsum ipsum lorem.</p>");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("\t        ");
            _builder.append("<p>example@example.com</p>");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("\t        ");
            _builder.append("<p><button class=\"button\">Contact</button></p>");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("      \t");
            _builder.append("</div>");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("</div>");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("</div>");
            _builder.newLine();
            _builder.append("\t");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("</div>");
    _builder.newLine();
    return _builder;
  }

  public CharSequence generateHtmlCode3User(final Entity e) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<!-- Add icon library -->");
    _builder.newLine();
    _builder.append("<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">");
    _builder.newLine();
    _builder.append("<link rel=\"stylesheet\" href=\"./style.css\">");
    _builder.newLine();
    _builder.newLine();
    _builder.newLine();
    _builder.append("All features");
    _builder.newLine();
    {
      EList<Feature> _features = e.getFeatures();
      for(final Feature f : _features) {
        String _name = f.getName();
        _builder.append(_name);
        _builder.append(" - ");
        String _get = f.getLiteral().get(0);
        _builder.append(_get);
        _builder.append(" <br>");
        _builder.newLineIfNotEmpty();
        String _name_1 = f.getName();
        _builder.append(_name_1);
        _builder.append(" - ");
        String _replace = f.getLiteral().get(0).replace("\"", "");
        _builder.append(_replace);
        _builder.append("<br>");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("Filter a single one<br>");
    _builder.newLine();
    {
      final Function1<Feature, Boolean> _function = (Feature it) -> {
        String _name_2 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_2, "tlfn"));
      };
      Iterable<Feature> _filter = IterableExtensions.<Feature>filter(e.getFeatures(), _function);
      for(final Feature f_1 : _filter) {
        String _name_2 = f_1.getName();
        _builder.append(_name_2);
        _builder.append(" - ");
        String _get_1 = f_1.getLiteral().get(0);
        _builder.append(_get_1);
        _builder.append("<br>");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("You need to:<br>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("Use name for the static picture file<br>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("Name<br>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("Position<br>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("Location (UAM)<br>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("4 links (linkedin, twitter, github, scholar?)<br>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("Finish the contact button - put mail on it<br>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<div class=\"card\">");
    _builder.newLine();
    {
      final Function1<Feature, Boolean> _function_1 = (Feature it) -> {
        String _name_3 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_3, "id"));
      };
      Iterable<Feature> _filter_1 = IterableExtensions.<Feature>filter(e.getFeatures(), _function_1);
      for(final Feature f_2 : _filter_1) {
        _builder.append("<img src=\"..\\..\\static\\");
        String _replace_1 = f_2.getLiteral().get(0).replace("\"", "");
        _builder.append(_replace_1);
        _builder.append(".png\" alt=");
        String _get_2 = f_2.getLiteral().get(0);
        _builder.append(_get_2);
        _builder.append(" style=\"width:100%\">");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("  ");
    _builder.append("<h1>John Doe</h1>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<p class=\"title\">CEO & Founder, Example</p>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<p>Universidad autónoma de Madrid</p>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<a href=\"#\"><i class=\"fa fa-dribbble\"></i></a>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<a href=\"#\"><i class=\"fa fa-twitter\"></i></a>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<a href=\"#\"><i class=\"fa fa-linkedin\"></i></a>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<a href=\"#\"><i class=\"fa fa-facebook\"></i></a>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<p><button>Contact</button></p>");
    _builder.newLine();
    _builder.append("    ");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<script>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("function goBack() {");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("window.history.back()");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("}");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</script>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<p>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<button onclick=\"goBack()\">Return</button>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</p>");
    _builder.newLine();
    _builder.append("</div> ");
    _builder.newLine();
    return _builder;
  }

  public CharSequence generateHtmlCodeDEBUG(final Entity... e) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<!DOCTYPE html>");
    _builder.newLine();
    _builder.append("<html lang=\"en\" >");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Template"));
      };
      Iterable<Entity> _filter = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function);
      for(final Entity i : _filter) {
        {
          EList<Feature> _features = i.getFeatures();
          for(final Feature f : _features) {
            _builder.append("FEATURE ");
            String _name = f.getName();
            _builder.append(_name);
            _builder.append(" = ");
            String _get = f.getLiteral().get(0);
            _builder.append(_get);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("<br>");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
}
