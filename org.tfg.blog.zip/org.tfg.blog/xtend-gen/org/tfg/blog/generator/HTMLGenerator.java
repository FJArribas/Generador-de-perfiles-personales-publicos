package org.tfg.blog.generator;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.tfg.blog.myBlog.AbstractElement;
import org.tfg.blog.myBlog.Entity;
import org.tfg.blog.myBlog.Feature;
import org.tfg.blog.myBlog.PackageDeclaration;
import org.tfg.blog.utils.IOUtils;

@SuppressWarnings("all")
public class HTMLGenerator {
  public CharSequence generateHtmlCode1(final Entity... e) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<!DOCTYPE html>");
    _builder.newLine();
    _builder.append("<html lang=\"en\" >");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<head>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<meta charset=\"UTF-8\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Site"));
      };
      Iterable<Entity> _filter = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function);
      for(final Entity i : _filter) {
        {
          final Function1<Feature, Boolean> _function_1 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "name"));
          };
          Iterable<Feature> _filter_1 = IterableExtensions.<Feature>filter(i.getFeatures(), _function_1);
          for(final Feature f : _filter_1) {
            _builder.append("\t\t");
            _builder.append("<title>");
            String _replace = f.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace, "\t\t");
            _builder.append("</title>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.1.0/css/all.css\" integrity=\"sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt\" crossorigin=\"anonymous\"><link rel=\"stylesheet\" href=\"https://public.codepenassets.com/css/normalize-5.0.0.min.css\">");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<link rel=\"stylesheet\" href=\"./style.css\">");
    _builder.newLine();
    _builder.append("</head>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<body>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<!-- MAIN CONTAINER -->");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<div class=\"resume\">");
    _builder.newLine();
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_2 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Sections"));
      };
      Iterable<Entity> _filter_2 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_2);
      for(final Entity x : _filter_2) {
        {
          final Function1<Feature, Boolean> _function_3 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "sidebar"));
          };
          Iterable<Feature> _filter_3 = IterableExtensions.<Feature>filter(x.getFeatures(), _function_3);
          for(final Feature z : _filter_3) {
            {
              String _replace_1 = z.getLiteral().get(0).replace("\"", "");
              boolean _equals = Objects.equals(_replace_1, "on");
              if (_equals) {
                _builder.newLine();
                _builder.append("<!-- SIDEBAR -->");
                _builder.newLine();
                _builder.append("<div class=\"base\">");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<div class=\"profile\">");
                _builder.newLine();
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<!-- PROFILE PICTURE -->");
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<div class=\"photo\">");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_4 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "Sources"));
                  };
                  Iterable<Entity> _filter_4 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_4);
                  for(final Entity i_1 : _filter_4) {
                    {
                      final Function1<Feature, Boolean> _function_5 = (Feature it) -> {
                        String _name = it.getName();
                        return Boolean.valueOf(Objects.equals(_name, "photo"));
                      };
                      Iterable<Feature> _filter_5 = IterableExtensions.<Feature>filter(i_1.getFeatures(), _function_5);
                      for(final Feature f_1 : _filter_5) {
                        _builder.append("\t\t\t");
                        _builder.append("<img src=");
                        String _replace_2 = f_1.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_2, "\t\t\t");
                        _builder.append(" />");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
                _builder.append("\t\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<!-- NAME AND OCCUPATION -->");
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<div class=\"info\">");
                _builder.newLine();
                _builder.append("\t\t");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_6 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "Site"));
                  };
                  Iterable<Entity> _filter_6 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_6);
                  for(final Entity i_2 : _filter_6) {
                    {
                      final Function1<Feature, Boolean> _function_7 = (Feature it) -> {
                        String _name = it.getName();
                        return Boolean.valueOf(Objects.equals(_name, "author"));
                      };
                      Iterable<Feature> _filter_7 = IterableExtensions.<Feature>filter(i_2.getFeatures(), _function_7);
                      for(final Feature f_2 : _filter_7) {
                        _builder.append("\t\t\t");
                        _builder.append("<h1 class=\"name\">");
                        String _replace_3 = f_2.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_3, "\t\t\t");
                        _builder.append("</h1>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                    {
                      final Function1<Feature, Boolean> _function_8 = (Feature it) -> {
                        String _name = it.getName();
                        return Boolean.valueOf(Objects.equals(_name, "position"));
                      };
                      Iterable<Feature> _filter_8 = IterableExtensions.<Feature>filter(i_2.getFeatures(), _function_8);
                      for(final Feature f_3 : _filter_8) {
                        _builder.append("\t\t\t");
                        _builder.append("<h1 class=\"name\">");
                        String _replace_4 = f_3.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_4, "\t\t\t");
                        _builder.append("</h1>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
                _builder.append("\t\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<!-- ABOUT ME -->");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<div class=\"about\" id=\"contact\">");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_9 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "Site"));
                  };
                  Iterable<Entity> _filter_9 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_9);
                  for(final Entity i_3 : _filter_9) {
                    {
                      final Function1<Feature, Boolean> _function_10 = (Feature it) -> {
                        String _name = it.getName();
                        return Boolean.valueOf(Objects.equals(_name, "bio"));
                      };
                      Iterable<Feature> _filter_10 = IterableExtensions.<Feature>filter(i_3.getFeatures(), _function_10);
                      for(final Feature f_4 : _filter_10) {
                        _builder.append("\t\t");
                        _builder.append("<h3>About Me</h3>");
                        String _replace_5 = f_4.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_5, "\t\t");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
                _builder.append("\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<!-- CONTACT -->");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<div class=\"contact\">");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<h3>Contact Me</h3>");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_11 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "Contact"));
                  };
                  Iterable<Entity> _filter_11 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_11);
                  for(final Entity i_4 : _filter_11) {
                    {
                      EList<Feature> _features = i_4.getFeatures();
                      for(final Feature f_5 : _features) {
                        _builder.append("<div class=");
                        String _name = f_5.getName();
                        _builder.append(_name);
                        _builder.append("><a href=");
                        String _get = f_5.getLiteral().get(0);
                        _builder.append(_get);
                        _builder.append(">");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t\t\t\t\t\t\t\t");
                        _builder.append("<i class=");
                        String _get_1 = f_5.getLiteral().get(1);
                        _builder.append(_get_1, "\t\t\t\t\t\t\t\t\t");
                        _builder.append("></i><span>");
                        String _replace_6 = f_5.getLiteral().get(2).replace("\"", "");
                        _builder.append(_replace_6, "\t\t\t\t\t\t\t\t\t");
                        _builder.append("</span></a>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t\t\t\t\t\t\t");
                        _builder.append("</div>");
                        _builder.newLine();
                      }
                    }
                  }
                }
                _builder.append("\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<!-- SOCIALS -->");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<div class=\"follow\">");
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<h3>Follow Me</h3>");
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<div class=\"box\">");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_12 = (Entity it) -> {
                    String _name_1 = it.getName();
                    return Boolean.valueOf(Objects.equals(_name_1, "Socials"));
                  };
                  Iterable<Entity> _filter_12 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_12);
                  for(final Entity i_5 : _filter_12) {
                    {
                      EList<Feature> _features_1 = i_5.getFeatures();
                      for(final Feature f_6 : _features_1) {
                        _builder.append("\t\t");
                        _builder.append("<a href=");
                        String _get_2 = f_6.getLiteral().get(0);
                        _builder.append(_get_2, "\t\t");
                        _builder.append(" target=\"_blank\"><i class=\"fab fa-");
                        String _name_1 = f_6.getName();
                        _builder.append(_name_1, "\t\t");
                        _builder.append("\"></i></a>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
                _builder.append("\t\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<!-- MAIN -->");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<div class=\"func\">");
    _builder.newLine();
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_13 = (Entity it) -> {
        String _name_2 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_2, "Sections"));
      };
      Iterable<Entity> _filter_13 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_13);
      for(final Entity x_1 : _filter_13) {
        {
          final Function1<Feature, Boolean> _function_14 = (Feature it) -> {
            String _name_2 = it.getName();
            return Boolean.valueOf(Objects.equals(_name_2, "menu"));
          };
          Iterable<Feature> _filter_14 = IterableExtensions.<Feature>filter(x_1.getFeatures(), _function_14);
          for(final Feature z_1 : _filter_14) {
            {
              String _replace_7 = z_1.getLiteral().get(0).replace("\"", "");
              boolean _equals_1 = Objects.equals(_replace_7, "on");
              if (_equals_1) {
                _builder.newLine();
                _builder.append("<!-- MENU -->");
                _builder.newLine();
                _builder.append("<div class=\"scrollmenu\" id=\"home\">");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_15 = (Entity it) -> {
                    String _name_2 = it.getName();
                    return Boolean.valueOf(Objects.equals(_name_2, "Menu"));
                  };
                  Iterable<Entity> _filter_15 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_15);
                  for(final Entity i_6 : _filter_15) {
                    {
                      final Function1<Feature, Boolean> _function_16 = (Feature it) -> {
                        String _name_2 = it.getName();
                        return Boolean.valueOf((!Objects.equals(_name_2, "Recommendations")));
                      };
                      Iterable<Feature> _filter_16 = IterableExtensions.<Feature>filter(i_6.getFeatures(), _function_16);
                      for(final Feature f_7 : _filter_16) {
                        _builder.append("<a href=");
                        String _get_3 = f_7.getLiteral().get(0);
                        _builder.append(_get_3);
                        _builder.append(">");
                        String _name_2 = f_7.getName();
                        _builder.append(_name_2);
                        _builder.append("</a>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                    {
                      final Function1<Feature, Boolean> _function_17 = (Feature it) -> {
                        String _name_3 = it.getName();
                        return Boolean.valueOf(Objects.equals(_name_3, "Recommendations"));
                      };
                      Iterable<Feature> _filter_17 = IterableExtensions.<Feature>filter(i_6.getFeatures(), _function_17);
                      for(final Feature f_8 : _filter_17) {
                        _builder.append("<a href=\"recommendations.html\"> ");
                        String _name_3 = f_8.getName();
                        _builder.append(_name_3);
                        _builder.append("</a>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_18 = (Entity it) -> {
        String _name_4 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_4, "Sections"));
      };
      Iterable<Entity> _filter_18 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_18);
      for(final Entity x_2 : _filter_18) {
        {
          final Function1<Feature, Boolean> _function_19 = (Feature it) -> {
            String _name_4 = it.getName();
            return Boolean.valueOf(Objects.equals(_name_4, "education"));
          };
          Iterable<Feature> _filter_19 = IterableExtensions.<Feature>filter(x_2.getFeatures(), _function_19);
          for(final Feature edu : _filter_19) {
            {
              final Function1<Feature, Boolean> _function_20 = (Feature it) -> {
                String _name_4 = it.getName();
                return Boolean.valueOf(Objects.equals(_name_4, "experience"));
              };
              Iterable<Feature> _filter_20 = IterableExtensions.<Feature>filter(x_2.getFeatures(), _function_20);
              for(final Feature exp : _filter_20) {
                {
                  if ((Objects.equals(edu.getLiteral().get(0).replace("\"", ""), "on") && Objects.equals(exp.getLiteral().get(0).replace("\"", ""), "on"))) {
                    _builder.newLine();
                    _builder.append("<!-- EDUCATION -->");
                    _builder.newLine();
                    _builder.append("<div class=\"edu\" id=\"education\">");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<h3><i class=\"fa fa-graduation-cap\"></i>Education</h3>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<ul>");
                    _builder.newLine();
                    {
                      final Function1<Entity, Boolean> _function_21 = (Entity it) -> {
                        String _name_4 = it.getName();
                        return Boolean.valueOf(Objects.equals(_name_4, "Education"));
                      };
                      Iterable<Entity> _filter_21 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_21);
                      for(final Entity i_7 : _filter_21) {
                        {
                          EList<Feature> _features_2 = i_7.getFeatures();
                          for(final Feature f_9 : _features_2) {
                            _builder.append("\t\t");
                            _builder.append("<li><span>");
                            String _replace_8 = f_9.getLiteral().get(0).replace("\"", "");
                            _builder.append(_replace_8, "\t\t");
                            _builder.append("</span><small>");
                            String _replace_9 = f_9.getLiteral().get(1).replace("\"", "");
                            _builder.append(_replace_9, "\t\t");
                            _builder.append("</small><small>");
                            String _replace_10 = f_9.getLiteral().get(2).replace("\"", "");
                            _builder.append(_replace_10, "\t\t");
                            _builder.append("</small></li>");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                    _builder.append("\t");
                    _builder.append("</ul>");
                    _builder.newLine();
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.newLine();
                    _builder.append("<!-- EXPERIENCE -->");
                    _builder.newLine();
                    _builder.append("<div class=\"work\" id=\"experience\">");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<h3><i class=\"fa fa-briefcase\"></i>Experience</h3>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<ul>");
                    _builder.newLine();
                    {
                      final Function1<Entity, Boolean> _function_22 = (Entity it) -> {
                        String _name_4 = it.getName();
                        return Boolean.valueOf(Objects.equals(_name_4, "Experience"));
                      };
                      Iterable<Entity> _filter_22 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_22);
                      for(final Entity i_8 : _filter_22) {
                        {
                          EList<Feature> _features_3 = i_8.getFeatures();
                          for(final Feature f_10 : _features_3) {
                            _builder.append("\t\t");
                            _builder.append("<li><span>");
                            String _replace_11 = f_10.getLiteral().get(0).replace("\"", "");
                            _builder.append(_replace_11, "\t\t");
                            _builder.append("</span><small>");
                            String _replace_12 = f_10.getLiteral().get(1).replace("\"", "");
                            _builder.append(_replace_12, "\t\t");
                            _builder.append("</small><small>");
                            String _replace_13 = f_10.getLiteral().get(2).replace("\"", "");
                            _builder.append(_replace_13, "\t\t");
                            _builder.append("</small></li>");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                    _builder.append("\t");
                    _builder.append("</ul>");
                    _builder.newLine();
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.newLine();
                  }
                }
                _builder.newLine();
                {
                  if ((Objects.equals(edu.getLiteral().get(0).replace("\"", ""), "on") && (!Objects.equals(exp.getLiteral().get(0).replace("\"", ""), "on")))) {
                    _builder.newLine();
                    _builder.append("<!-- EDUCATION -->");
                    _builder.newLine();
                    _builder.append("<div class=\"teaching\" id=\"education\">");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<h3><i class=\"fa fa-graduation-cap\"></i>Education</h3>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<ul>");
                    _builder.newLine();
                    {
                      final Function1<Entity, Boolean> _function_23 = (Entity it) -> {
                        String _name_4 = it.getName();
                        return Boolean.valueOf(Objects.equals(_name_4, "Education"));
                      };
                      Iterable<Entity> _filter_23 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_23);
                      for(final Entity i_9 : _filter_23) {
                        {
                          EList<Feature> _features_4 = i_9.getFeatures();
                          for(final Feature f_11 : _features_4) {
                            _builder.append("\t\t");
                            _builder.append("<li><span>");
                            String _replace_14 = f_11.getLiteral().get(0).replace("\"", "");
                            _builder.append(_replace_14, "\t\t");
                            _builder.append("</span><small>");
                            String _replace_15 = f_11.getLiteral().get(1).replace("\"", "");
                            _builder.append(_replace_15, "\t\t");
                            _builder.append("</small><small>");
                            String _replace_16 = f_11.getLiteral().get(2).replace("\"", "");
                            _builder.append(_replace_16, "\t\t");
                            _builder.append("</small></li>");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                    _builder.append("\t");
                    _builder.append("</ul>");
                    _builder.newLine();
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.newLine();
                  }
                }
                _builder.newLine();
                {
                  if (((!Objects.equals(edu.getLiteral().get(0).replace("\"", ""), "on")) && Objects.equals(exp.getLiteral().get(0).replace("\"", ""), "on"))) {
                    _builder.newLine();
                    _builder.append("<!-- EXPERIENCE -->");
                    _builder.newLine();
                    _builder.append("<div class=\"teaching\" id=\"experience\">");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<h3><i class=\"fa fa-briefcase\"></i>Experience</h3>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<ul>");
                    _builder.newLine();
                    {
                      final Function1<Entity, Boolean> _function_24 = (Entity it) -> {
                        String _name_4 = it.getName();
                        return Boolean.valueOf(Objects.equals(_name_4, "Experience"));
                      };
                      Iterable<Entity> _filter_24 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_24);
                      for(final Entity i_10 : _filter_24) {
                        {
                          EList<Feature> _features_5 = i_10.getFeatures();
                          for(final Feature f_12 : _features_5) {
                            _builder.append("\t\t");
                            _builder.append("<li><span>");
                            String _replace_17 = f_12.getLiteral().get(0).replace("\"", "");
                            _builder.append(_replace_17, "\t\t");
                            _builder.append("</span><small>");
                            String _replace_18 = f_12.getLiteral().get(1).replace("\"", "");
                            _builder.append(_replace_18, "\t\t");
                            _builder.append("</small><small>");
                            String _replace_19 = f_12.getLiteral().get(2).replace("\"", "");
                            _builder.append(_replace_19, "\t\t");
                            _builder.append("</small></li>");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                    _builder.append("\t");
                    _builder.append("</ul>");
                    _builder.newLine();
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.newLine();
                  }
                }
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_25 = (Entity it) -> {
        String _name_4 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_4, "Sections"));
      };
      Iterable<Entity> _filter_25 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_25);
      for(final Entity x_3 : _filter_25) {
        {
          final Function1<Feature, Boolean> _function_26 = (Feature it) -> {
            String _name_4 = it.getName();
            return Boolean.valueOf(Objects.equals(_name_4, "teaching"));
          };
          Iterable<Feature> _filter_26 = IterableExtensions.<Feature>filter(x_3.getFeatures(), _function_26);
          for(final Feature z_2 : _filter_26) {
            {
              String _replace_20 = z_2.getLiteral().get(0).replace("\"", "");
              boolean _equals_2 = Objects.equals(_replace_20, "on");
              if (_equals_2) {
                _builder.newLine();
                _builder.append("<!-- TEACHING -->");
                _builder.newLine();
                _builder.append("<div class=\"teaching\" id=\"teaching\">");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<h3><i class=\"fa fa-list-ol\"></i>Teaching</h3>");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_27 = (Entity it) -> {
                    String _name_4 = it.getName();
                    return Boolean.valueOf(Objects.equals(_name_4, "TeachingBSc"));
                  };
                  Iterable<Entity> _filter_27 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_27);
                  for(final Entity i_11 : _filter_27) {
                    {
                      final Function1<Feature, Boolean> _function_28 = (Feature it) -> {
                        String _name_4 = it.getName();
                        return Boolean.valueOf(Objects.equals(_name_4, "intro"));
                      };
                      Iterable<Feature> _filter_28 = IterableExtensions.<Feature>filter(i_11.getFeatures(), _function_28);
                      for(final Feature f_13 : _filter_28) {
                        _builder.append("\t");
                        _builder.append("\t");
                        String _replace_21 = f_13.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_21, "\t\t");
                        _builder.append(" ");
                        String _replace_22 = f_13.getLiteral().get(3).replace("\"", "");
                        _builder.append(_replace_22, "\t\t");
                        _builder.append("<br>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t");
                        _builder.append("\t");
                        _builder.append("<a href=");
                        String _get_4 = f_13.getLiteral().get(1);
                        _builder.append(_get_4, "\t\t");
                        _builder.append(">");
                        String _replace_23 = f_13.getLiteral().get(2).replace("\"", "");
                        _builder.append(_replace_23, "\t\t");
                        _builder.append("</a>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                    _builder.append("\t");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<ul>");
                    _builder.newLine();
                    {
                      final Function1<Feature, Boolean> _function_29 = (Feature it) -> {
                        String _name_4 = it.getName();
                        return Boolean.valueOf((!Objects.equals(_name_4, "intro")));
                      };
                      Iterable<Feature> _filter_29 = IterableExtensions.<Feature>filter(i_11.getFeatures(), _function_29);
                      for(final Feature f_14 : _filter_29) {
                        _builder.append("\t");
                        _builder.append("\t");
                        _builder.append("<li><span>");
                        String _replace_24 = f_14.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_24, "\t\t");
                        _builder.append("</span><small>");
                        String _replace_25 = f_14.getLiteral().get(1).replace("\"", "");
                        _builder.append(_replace_25, "\t\t");
                        _builder.append("</small><small>");
                        String _replace_26 = f_14.getLiteral().get(2).replace("\"", "");
                        _builder.append(_replace_26, "\t\t");
                        _builder.append("</small></li>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                    _builder.append("\t");
                    _builder.append("</ul>");
                    _builder.newLine();
                  }
                }
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_30 = (Entity it) -> {
                    String _name_4 = it.getName();
                    return Boolean.valueOf(Objects.equals(_name_4, "TeachingMSc"));
                  };
                  Iterable<Entity> _filter_30 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_30);
                  for(final Entity i_12 : _filter_30) {
                    {
                      final Function1<Feature, Boolean> _function_31 = (Feature it) -> {
                        String _name_4 = it.getName();
                        return Boolean.valueOf(Objects.equals(_name_4, "intro"));
                      };
                      Iterable<Feature> _filter_31 = IterableExtensions.<Feature>filter(i_12.getFeatures(), _function_31);
                      for(final Feature f_15 : _filter_31) {
                        _builder.append("\t");
                        _builder.append("\t");
                        String _replace_27 = f_15.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_27, "\t\t");
                        _builder.append(" ");
                        String _replace_28 = f_15.getLiteral().get(3).replace("\"", "");
                        _builder.append(_replace_28, "\t\t");
                        _builder.append("<br>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t");
                        _builder.append("\t");
                        _builder.append("<a href=");
                        String _get_5 = f_15.getLiteral().get(1);
                        _builder.append(_get_5, "\t\t");
                        _builder.append(">");
                        String _replace_29 = f_15.getLiteral().get(2).replace("\"", "");
                        _builder.append(_replace_29, "\t\t");
                        _builder.append("</a>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                    _builder.append("\t");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<ul>");
                    _builder.newLine();
                    {
                      final Function1<Feature, Boolean> _function_32 = (Feature it) -> {
                        String _name_4 = it.getName();
                        return Boolean.valueOf((!Objects.equals(_name_4, "intro")));
                      };
                      Iterable<Feature> _filter_32 = IterableExtensions.<Feature>filter(i_12.getFeatures(), _function_32);
                      for(final Feature f_16 : _filter_32) {
                        _builder.append("\t");
                        _builder.append("\t");
                        _builder.append("<li><span>");
                        String _replace_30 = f_16.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_30, "\t\t");
                        _builder.append("</span><small>");
                        String _replace_31 = f_16.getLiteral().get(1).replace("\"", "");
                        _builder.append(_replace_31, "\t\t");
                        _builder.append("</small><small>");
                        String _replace_32 = f_16.getLiteral().get(2).replace("\"", "");
                        _builder.append(_replace_32, "\t\t");
                        _builder.append("</small></li>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                    _builder.append("\t");
                    _builder.append("</ul>");
                    _builder.newLine();
                  }
                }
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_33 = (Entity it) -> {
        String _name_4 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_4, "Sections"));
      };
      Iterable<Entity> _filter_33 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_33);
      for(final Entity x_4 : _filter_33) {
        {
          final Function1<Feature, Boolean> _function_34 = (Feature it) -> {
            String _name_4 = it.getName();
            return Boolean.valueOf(Objects.equals(_name_4, "skills_1"));
          };
          Iterable<Feature> _filter_34 = IterableExtensions.<Feature>filter(x_4.getFeatures(), _function_34);
          for(final Feature z_3 : _filter_34) {
            {
              String _replace_33 = z_3.getLiteral().get(0).replace("\"", "");
              boolean _equals_3 = Objects.equals(_replace_33, "on");
              if (_equals_3) {
                _builder.newLine();
                _builder.append("<!-- PROGRAMMING SKILLS -->");
                _builder.newLine();
                _builder.append("<div class=\"skills-prog\" id=\"skills-prog\">");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<h3><i class=\"fas fa-code\"></i>Programming Skills</h3>");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<ul>");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_35 = (Entity it) -> {
                    String _name_4 = it.getName();
                    return Boolean.valueOf(Objects.equals(_name_4, "Programming"));
                  };
                  Iterable<Entity> _filter_35 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_35);
                  for(final Entity i_13 : _filter_35) {
                    {
                      EList<Feature> _features_6 = i_13.getFeatures();
                      for(final Feature f_17 : _features_6) {
                        _builder.append("\t\t");
                        _builder.append("<li data-percent=");
                        String _get_6 = f_17.getLiteral().get(1);
                        _builder.append(_get_6, "\t\t");
                        _builder.append("><span>");
                        String _replace_34 = f_17.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_34, "\t\t");
                        _builder.append("</span>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t");
                        _builder.append("<div class=\"skills-bar\">");
                        _builder.newLine();
                        _builder.append("\t\t");
                        _builder.append(" \t");
                        _builder.append("<div class=\"bar\"></div>");
                        _builder.newLine();
                        _builder.append("\t\t");
                        _builder.append("</div>");
                        _builder.newLine();
                        _builder.append("\t\t");
                        _builder.append("</li>");
                        _builder.newLine();
                      }
                    }
                  }
                }
                _builder.append("\t");
                _builder.append("</ul>");
                _builder.newLine();
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_36 = (Entity it) -> {
        String _name_4 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_4, "Sections"));
      };
      Iterable<Entity> _filter_36 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_36);
      for(final Entity x_5 : _filter_36) {
        {
          final Function1<Feature, Boolean> _function_37 = (Feature it) -> {
            String _name_4 = it.getName();
            return Boolean.valueOf(Objects.equals(_name_4, "skills_2"));
          };
          Iterable<Feature> _filter_37 = IterableExtensions.<Feature>filter(x_5.getFeatures(), _function_37);
          for(final Feature z_4 : _filter_37) {
            {
              String _replace_35 = z_4.getLiteral().get(0).replace("\"", "");
              boolean _equals_4 = Objects.equals(_replace_35, "on");
              if (_equals_4) {
                _builder.newLine();
                _builder.append("<!-- SOFTWARE SKILLS -->");
                _builder.newLine();
                _builder.append("<div class=\"skills-soft\">");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<h3><i class=\"fas fa-bezier-curve\"></i>Software Skills</h3>");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<ul>");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_38 = (Entity it) -> {
                    String _name_4 = it.getName();
                    return Boolean.valueOf(Objects.equals(_name_4, "Skills"));
                  };
                  Iterable<Entity> _filter_38 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_38);
                  for(final Entity i_14 : _filter_38) {
                    {
                      EList<Feature> _features_7 = i_14.getFeatures();
                      for(final Feature f_18 : _features_7) {
                        _builder.append("\t\t");
                        _builder.append("<li data-percent=");
                        String _get_7 = f_18.getLiteral().get(1);
                        _builder.append(_get_7, "\t\t");
                        _builder.append(">");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t");
                        _builder.append("\t");
                        _builder.append("<svg viewbox=\"0 0 100 100\">");
                        _builder.newLine();
                        _builder.append("\t\t");
                        _builder.append("\t\t");
                        _builder.append("<circle cx=\"50\" cy=\"50\" r=\"45\"></circle>");
                        _builder.newLine();
                        _builder.append("\t\t");
                        _builder.append("\t\t");
                        _builder.append("<circle class=\"cbar\" cx=\"50\" cy=\"50\" r=\"45\"></circle>");
                        _builder.newLine();
                        _builder.append("\t\t");
                        _builder.append("\t");
                        _builder.append("</svg><span>");
                        String _replace_36 = f_18.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_36, "\t\t\t");
                        _builder.append("</span><small></small>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t");
                        _builder.append("</li>");
                        _builder.newLine();
                      }
                    }
                  }
                }
                _builder.append("\t");
                _builder.append("</ul>");
                _builder.newLine();
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_39 = (Entity it) -> {
        String _name_4 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_4, "Sections"));
      };
      Iterable<Entity> _filter_39 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_39);
      for(final Entity x_6 : _filter_39) {
        {
          final Function1<Feature, Boolean> _function_40 = (Feature it) -> {
            String _name_4 = it.getName();
            return Boolean.valueOf(Objects.equals(_name_4, "interests"));
          };
          Iterable<Feature> _filter_40 = IterableExtensions.<Feature>filter(x_6.getFeatures(), _function_40);
          for(final Feature z_5 : _filter_40) {
            {
              String _replace_37 = z_5.getLiteral().get(0).replace("\"", "");
              boolean _equals_5 = Objects.equals(_replace_37, "on");
              if (_equals_5) {
                _builder.newLine();
                _builder.append("<!-- INTERESTS -->");
                _builder.newLine();
                _builder.append("<div class=\"interests\">");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<h3><i class=\"fas fa-star\"></i>Interests</h3>");
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<div class=\"interests-items\">");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_41 = (Entity it) -> {
                    String _name_4 = it.getName();
                    return Boolean.valueOf(Objects.equals(_name_4, "Interests"));
                  };
                  Iterable<Entity> _filter_41 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_41);
                  for(final Entity i_15 : _filter_41) {
                    {
                      EList<Feature> _features_8 = i_15.getFeatures();
                      for(final Feature f_19 : _features_8) {
                        _builder.append("<div class=\"art\"><i class=");
                        String _get_8 = f_19.getLiteral().get(1);
                        _builder.append(_get_8);
                        _builder.append("></i><span style=\"width:130px; word-wrap:break-word; display:inline-block;\">");
                        String _replace_38 = f_19.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_38);
                        _builder.append("</span></div>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
                _builder.append("\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_42 = (Entity it) -> {
        String _name_4 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_4, "Sections"));
      };
      Iterable<Entity> _filter_42 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_42);
      for(final Entity x_7 : _filter_42) {
        {
          final Function1<Feature, Boolean> _function_43 = (Feature it) -> {
            String _name_4 = it.getName();
            return Boolean.valueOf(Objects.equals(_name_4, "hobbies"));
          };
          Iterable<Feature> _filter_43 = IterableExtensions.<Feature>filter(x_7.getFeatures(), _function_43);
          for(final Feature z_6 : _filter_43) {
            {
              String _replace_39 = z_6.getLiteral().get(0).replace("\"", "");
              boolean _equals_6 = Objects.equals(_replace_39, "on");
              if (_equals_6) {
                _builder.newLine();
                _builder.append("<!-- HOBBIES -->");
                _builder.newLine();
                _builder.append("<div class=\"interests\">");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<h3><i class=\"fas fa-star\"></i>Hobbies</h3>");
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<div class=\"interests-items\">");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_44 = (Entity it) -> {
                    String _name_4 = it.getName();
                    return Boolean.valueOf(Objects.equals(_name_4, "Hobbies"));
                  };
                  Iterable<Entity> _filter_44 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_44);
                  for(final Entity i_16 : _filter_44) {
                    {
                      EList<Feature> _features_9 = i_16.getFeatures();
                      for(final Feature f_20 : _features_9) {
                        _builder.append("<div class=\"art\"><i class=");
                        String _get_9 = f_20.getLiteral().get(1);
                        _builder.append(_get_9);
                        _builder.append("></i><span style=\"width:130px; word-wrap:break-word; display:inline-block;\">");
                        String _replace_40 = f_20.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_40);
                        _builder.append("</span></div>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
                _builder.append("\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    _builder.append("<!-- BLOG POSTS -->");
    _builder.newLine();
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_45 = (Entity it) -> {
        String _name_4 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_4, "Sections"));
      };
      Iterable<Entity> _filter_45 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_45);
      for(final Entity x_8 : _filter_45) {
        {
          final Function1<Feature, Boolean> _function_46 = (Feature it) -> {
            String _name_4 = it.getName();
            return Boolean.valueOf(Objects.equals(_name_4, "blog"));
          };
          Iterable<Feature> _filter_46 = IterableExtensions.<Feature>filter(x_8.getFeatures(), _function_46);
          for(final Feature z_7 : _filter_46) {
            {
              String _replace_41 = z_7.getLiteral().get(0).replace("\"", "");
              boolean _equals_7 = Objects.equals(_replace_41, "on");
              if (_equals_7) {
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_47 = (Entity it) -> {
                    String _name_4 = it.getName();
                    return Boolean.valueOf(Objects.equals(_name_4, "Sources"));
                  };
                  Iterable<Entity> _filter_47 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_47);
                  for(final Entity i_17 : _filter_47) {
                    {
                      final Function1<Feature, Boolean> _function_48 = (Feature it) -> {
                        String _name_4 = it.getName();
                        return Boolean.valueOf(Objects.equals(_name_4, "posts"));
                      };
                      Iterable<Feature> _filter_48 = IterableExtensions.<Feature>filter(i_17.getFeatures(), _function_48);
                      for(final Feature f_21 : _filter_48) {
                        {
                          List<Map.Entry<String, String>> _massConvert = IOUtils.massConvert(f_21.getLiteral().get(0).replace("\"", ""));
                          for(final Map.Entry<String, String> p : _massConvert) {
                            _builder.append("<div class=\"blog\" id=\"blog\">");
                            _builder.newLine();
                            _builder.append("<h3><i class=\"fas fa-paragraph\"></i>");
                            String _key = p.getKey();
                            _builder.append(_key);
                            _builder.append("</h3>");
                            _builder.newLineIfNotEmpty();
                            _builder.append("\t");
                            String _value = p.getValue();
                            _builder.append(_value, "\t");
                            _builder.newLineIfNotEmpty();
                            _builder.append("</div>");
                            _builder.newLine();
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<!-- partial -->");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<script src=\'https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js\'></script><script\tsrc=\"./script.js\"></script>");
    _builder.newLine();
    _builder.append("</body>");
    _builder.newLine();
    _builder.append("</html>");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }

  public CharSequence generateHtmlCode1Recoms(final Entity... e) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<!DOCTYPE html>");
    _builder.newLine();
    _builder.append("<html lang=\"en\" >");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<head>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<meta charset=\"UTF-8\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Site"));
      };
      Iterable<Entity> _filter = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function);
      for(final Entity i : _filter) {
        {
          final Function1<Feature, Boolean> _function_1 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "name"));
          };
          Iterable<Feature> _filter_1 = IterableExtensions.<Feature>filter(i.getFeatures(), _function_1);
          for(final Feature f : _filter_1) {
            _builder.append("\t\t");
            _builder.append("<title>");
            String _replace = f.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace, "\t\t");
            _builder.append("</title>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.1.0/css/all.css\" integrity=\"sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt\" crossorigin=\"anonymous\"><link rel=\"stylesheet\" href=\"https://public.codepenassets.com/css/normalize-5.0.0.min.css\">");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<link rel=\"stylesheet\" href=\"./style.css\">");
    _builder.newLine();
    _builder.append("</head>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<body>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<!-- MAIN CONTAINER -->");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<div class=\"resume\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<!-- SIDEBAR -->");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<div class=\"base\">");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<div class=\"profile\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t\t\t\t");
    _builder.append("<!-- PROFILE PICTURE -->");
    _builder.newLine();
    _builder.append("\t\t\t\t");
    _builder.append("<div class=\"photo\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_2 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Sources"));
      };
      Iterable<Entity> _filter_2 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_2);
      for(final Entity i_1 : _filter_2) {
        {
          final Function1<Feature, Boolean> _function_3 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "photo"));
          };
          Iterable<Feature> _filter_3 = IterableExtensions.<Feature>filter(i_1.getFeatures(), _function_3);
          for(final Feature f_1 : _filter_3) {
            _builder.append("\t\t\t\t\t");
            _builder.append("<img src=");
            String _replace_1 = f_1.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace_1, "\t\t\t\t\t");
            _builder.append(" />");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t\t\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t\t\t\t");
    _builder.append("<!-- NAME AND OCCUPATION -->");
    _builder.newLine();
    _builder.append("\t\t\t\t");
    _builder.append("<div class=\"info\">");
    _builder.newLine();
    _builder.append("\t\t\t\t");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_4 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Site"));
      };
      Iterable<Entity> _filter_4 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_4);
      for(final Entity i_2 : _filter_4) {
        {
          final Function1<Feature, Boolean> _function_5 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "author"));
          };
          Iterable<Feature> _filter_5 = IterableExtensions.<Feature>filter(i_2.getFeatures(), _function_5);
          for(final Feature f_2 : _filter_5) {
            _builder.append("\t\t\t\t\t");
            _builder.append("<h1 class=\"name\">");
            String _replace_2 = f_2.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace_2, "\t\t\t\t\t");
            _builder.append("</h1>");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          final Function1<Feature, Boolean> _function_6 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "position"));
          };
          Iterable<Feature> _filter_6 = IterableExtensions.<Feature>filter(i_2.getFeatures(), _function_6);
          for(final Feature f_3 : _filter_6) {
            _builder.append("\t\t\t\t\t");
            _builder.append("<h1 class=\"name\">");
            String _replace_3 = f_3.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace_3, "\t\t\t\t\t");
            _builder.append("</h1>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t\t\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<!-- ABOUT ME -->");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<div class=\"about\" id=\"contact\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_7 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Site"));
      };
      Iterable<Entity> _filter_7 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_7);
      for(final Entity i_3 : _filter_7) {
        {
          final Function1<Feature, Boolean> _function_8 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "bio"));
          };
          Iterable<Feature> _filter_8 = IterableExtensions.<Feature>filter(i_3.getFeatures(), _function_8);
          for(final Feature f_4 : _filter_8) {
            _builder.append("\t\t\t\t");
            _builder.append("<h3>About Me</h3>");
            String _replace_4 = f_4.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace_4, "\t\t\t\t");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<!-- CONTACT -->");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<div class=\"contact\">");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<h3>Contact Me</h3>");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_9 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Contact"));
      };
      Iterable<Entity> _filter_9 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_9);
      for(final Entity i_4 : _filter_9) {
        {
          EList<Feature> _features = i_4.getFeatures();
          for(final Feature f_5 : _features) {
            _builder.append("<div class=");
            String _name = f_5.getName();
            _builder.append(_name);
            _builder.append("><a href=");
            String _get = f_5.getLiteral().get(0);
            _builder.append(_get);
            _builder.append(">");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t\t\t\t\t\t\t\t");
            _builder.append("<i class=");
            String _get_1 = f_5.getLiteral().get(1);
            _builder.append(_get_1, "\t\t\t\t\t\t\t\t\t");
            _builder.append("></i><span>");
            String _replace_5 = f_5.getLiteral().get(2).replace("\"", "");
            _builder.append(_replace_5, "\t\t\t\t\t\t\t\t\t");
            _builder.append("</span></a>");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t\t\t\t\t\t\t");
            _builder.append("</div>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("\t\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<!-- SOCIALS -->");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<div class=\"follow\">");
    _builder.newLine();
    _builder.append("\t\t\t\t");
    _builder.append("<h3>Follow Me</h3>");
    _builder.newLine();
    _builder.append("\t\t\t\t");
    _builder.append("<div class=\"box\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_10 = (Entity it) -> {
        String _name_1 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_1, "Socials"));
      };
      Iterable<Entity> _filter_10 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_10);
      for(final Entity i_5 : _filter_10) {
        {
          EList<Feature> _features_1 = i_5.getFeatures();
          for(final Feature f_6 : _features_1) {
            _builder.append("\t\t\t\t");
            _builder.append("<a href=");
            String _get_2 = f_6.getLiteral().get(0);
            _builder.append(_get_2, "\t\t\t\t");
            _builder.append(" target=\"_blank\"><i class=\"fab fa-");
            String _name_1 = f_6.getName();
            _builder.append(_name_1, "\t\t\t\t");
            _builder.append("\"></i></a>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t\t\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<!-- MAIN -->");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<div class=\"func\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<!-- MENU -->");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<div class=\"scrollmenu\" id=\"home\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_11 = (Entity it) -> {
        String _name_2 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_2, "Menu"));
      };
      Iterable<Entity> _filter_11 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_11);
      for(final Entity i_6 : _filter_11) {
        {
          final Function1<Feature, Boolean> _function_12 = (Feature it) -> {
            String _name_2 = it.getName();
            return Boolean.valueOf((!Objects.equals(_name_2, "Recommendations")));
          };
          Iterable<Feature> _filter_12 = IterableExtensions.<Feature>filter(i_6.getFeatures(), _function_12);
          for(final Feature f_7 : _filter_12) {
            _builder.append("\t\t\t");
            _builder.append("<a href=\"index.html");
            String _replace_6 = f_7.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace_6, "\t\t\t");
            _builder.append("\"> ");
            String _name_2 = f_7.getName();
            _builder.append(_name_2, "\t\t\t");
            _builder.append("</a>");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          final Function1<Feature, Boolean> _function_13 = (Feature it) -> {
            String _name_3 = it.getName();
            return Boolean.valueOf(Objects.equals(_name_3, "Recommendations"));
          };
          Iterable<Feature> _filter_13 = IterableExtensions.<Feature>filter(i_6.getFeatures(), _function_13);
          for(final Feature f_8 : _filter_13) {
            _builder.append("\t\t\t");
            _builder.append("<a href=");
            String _get_3 = f_8.getLiteral().get(0);
            _builder.append(_get_3, "\t\t\t");
            _builder.append("> ");
            String _name_3 = f_8.getName();
            _builder.append(_name_3, "\t\t\t");
            _builder.append("</a>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("Some recommendations from people whom I have worked with.");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<!-- RECOMMENDATIONS -->");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<div class=\"recommendations\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_14 = (Entity it) -> {
        String _name_4 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_4, "Recommendations"));
      };
      Iterable<Entity> _filter_14 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_14);
      for(final Entity i_7 : _filter_14) {
        {
          EList<Feature> _features_2 = i_7.getFeatures();
          for(final Feature f_9 : _features_2) {
            _builder.append("\t\t\t");
            _builder.append("<div class=\"blog\" id=\"recommendations\">");
            _builder.newLine();
            _builder.append("\t\t\t");
            _builder.append("\t");
            _builder.append("<h3><i class=\"fas fa-star\"></i>");
            String _replace_7 = f_9.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace_7, "\t\t\t\t");
            _builder.append("</h3>");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t\t");
            _builder.append(" \t");
            _builder.append("<a href=");
            String _get_4 = f_9.getLiteral().get(1);
            _builder.append(_get_4, "\t\t\t \t");
            _builder.append(">");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t\t");
            _builder.append(" \t\t");
            _builder.append("<img src=");
            String _get_5 = f_9.getLiteral().get(2);
            _builder.append(_get_5, "\t\t\t \t\t");
            _builder.append(" alt=");
            String _get_6 = f_9.getLiteral().get(1);
            _builder.append(_get_6, "\t\t\t \t\t");
            _builder.append(" width=\"600\"\">");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t\t");
            _builder.append("\t");
            _builder.append("</a>");
            _builder.newLine();
            _builder.append("\t\t\t");
            _builder.append("</div>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("\t\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("</div>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<!-- partial -->");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<script src=\'https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js\'></script><script\tsrc=\"./script.js\"></script>");
    _builder.newLine();
    _builder.append("</body>");
    _builder.newLine();
    _builder.append("</html>");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }

  public CharSequence generateHtmlCode2(final Entity... e) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<!DOCTYPE html>");
    _builder.newLine();
    _builder.append("<html lang=\"en\" >");
    _builder.newLine();
    _builder.append("<head>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<meta charset=\"UTF-8\">");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Site"));
      };
      Iterable<Entity> _filter = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function);
      for(final Entity i : _filter) {
        {
          final Function1<Feature, Boolean> _function_1 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "name"));
          };
          Iterable<Feature> _filter_1 = IterableExtensions.<Feature>filter(i.getFeatures(), _function_1);
          for(final Feature f : _filter_1) {
            _builder.append("<title>");
            String _replace = f.getLiteral().get(0).replace("\"", "");
            _builder.append(_replace);
            _builder.append("</title>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("<link rel=\'stylesheet\' href=\'https://fonts.googleapis.com/css?family=Playfair+Display|PT+Sans\'>");
    _builder.newLine();
    _builder.append("<link rel=\'stylesheet\' href=\'https://s3-us-west-2.amazonaws.com/s.cdpn.io/85807/font-awesome.css\'>");
    _builder.newLine();
    _builder.append("<link rel=\'stylesheet\' href=\'https://fonts.googleapis.com/css?family=Montserrat:400, 700\'><link rel=\"stylesheet\" href=\"./style.css\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("</head>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<body>");
    _builder.newLine();
    _builder.append("<!-- MAIN CONTAINER -->");
    _builder.newLine();
    _builder.append("<!-- partial:index.partial.html -->");
    _builder.newLine();
    _builder.newLine();
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_2 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Sections"));
      };
      Iterable<Entity> _filter_2 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_2);
      for(final Entity x : _filter_2) {
        {
          final Function1<Feature, Boolean> _function_3 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "menu"));
          };
          Iterable<Feature> _filter_3 = IterableExtensions.<Feature>filter(x.getFeatures(), _function_3);
          for(final Feature z : _filter_3) {
            {
              String _replace_1 = z.getLiteral().get(0).replace("\"", "");
              boolean _equals = Objects.equals(_replace_1, "on");
              if (_equals) {
                _builder.append("<!-- TOP BAR -->");
                _builder.newLine();
                _builder.append("<div class=\"contOut clearfix\">");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<div class=\"contIn\">");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<div class=\"section top clearfix\">");
                _builder.newLine();
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<!-- PROFILE PICTURE -->");
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<div class=\"logoCont\">");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_4 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "Sources"));
                  };
                  Iterable<Entity> _filter_4 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_4);
                  for(final Entity i_1 : _filter_4) {
                    {
                      final Function1<Feature, Boolean> _function_5 = (Feature it) -> {
                        String _name = it.getName();
                        return Boolean.valueOf(Objects.equals(_name, "photo"));
                      };
                      Iterable<Feature> _filter_5 = IterableExtensions.<Feature>filter(i_1.getFeatures(), _function_5);
                      for(final Feature f_1 : _filter_5) {
                        _builder.append("\t\t\t");
                        _builder.append("<img class=\"logo\" src=");
                        String _replace_2 = f_1.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_2, "\t\t\t");
                        _builder.append(" />");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
                _builder.append("\t\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<!-- NAME -->");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_6 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "Site"));
                  };
                  Iterable<Entity> _filter_6 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_6);
                  for(final Entity i_2 : _filter_6) {
                    {
                      final Function1<Feature, Boolean> _function_7 = (Feature it) -> {
                        String _name = it.getName();
                        return Boolean.valueOf(Objects.equals(_name, "author"));
                      };
                      Iterable<Feature> _filter_7 = IterableExtensions.<Feature>filter(i_2.getFeatures(), _function_7);
                      for(final Feature f_2 : _filter_7) {
                        _builder.append("\t\t");
                        _builder.append("<h1>");
                        String _replace_3 = f_2.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_3, "\t\t");
                        _builder.append("</h1>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<!-- CONTACT -->");
                _builder.newLine();
                _builder.append("\t\t");
                _builder.append("<div class=\"moreInfo\">");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_8 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "Contact"));
                  };
                  Iterable<Entity> _filter_8 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_8);
                  for(final Entity i_3 : _filter_8) {
                    {
                      final Function1<Feature, Boolean> _function_9 = (Feature it) -> {
                        String _name = it.getName();
                        return Boolean.valueOf((!Objects.equals(_name, "address")));
                      };
                      Iterable<Feature> _filter_9 = IterableExtensions.<Feature>filter(i_3.getFeatures(), _function_9);
                      for(final Feature f_3 : _filter_9) {
                        _builder.append("\t\t");
                        _builder.append("<a href=");
                        String _get = f_3.getLiteral().get(0);
                        _builder.append(_get, "\t\t");
                        _builder.append(" target=\"_blank\">");
                        String _replace_4 = f_3.getLiteral().get(2).replace("\"", "");
                        _builder.append(_replace_4, "\t\t");
                        _builder.append("</a><br/>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
                _builder.append("\t\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_10 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "Site"));
                  };
                  Iterable<Entity> _filter_10 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_10);
                  for(final Entity i_4 : _filter_10) {
                    {
                      final Function1<Feature, Boolean> _function_11 = (Feature it) -> {
                        String _name = it.getName();
                        return Boolean.valueOf(Objects.equals(_name, "position"));
                      };
                      Iterable<Feature> _filter_11 = IterableExtensions.<Feature>filter(i_4.getFeatures(), _function_11);
                      for(final Feature f_4 : _filter_11) {
                        _builder.append("\t\t");
                        _builder.append("<p class=\"tagline\">");
                        String _replace_5 = f_4.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_5, "\t\t");
                        _builder.append("<br/>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t");
                        _builder.append("<span>");
                        String _replace_6 = f_4.getLiteral().get(1).replace("\"", "");
                        _builder.append(_replace_6, "\t\t");
                        _builder.append("t</span></p>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
                _builder.newLine();
                _builder.append("\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("<div class=\"divider\"></div>");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("</div>");
                _builder.newLine();
                _builder.append("</div>");
                _builder.newLine();
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    _builder.append("<!-- MAIN -->");
    _builder.newLine();
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_12 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Sections"));
      };
      Iterable<Entity> _filter_12 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_12);
      for(final Entity x_1 : _filter_12) {
        {
          final Function1<Feature, Boolean> _function_13 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "experience"));
          };
          Iterable<Feature> _filter_13 = IterableExtensions.<Feature>filter(x_1.getFeatures(), _function_13);
          for(final Feature z_1 : _filter_13) {
            {
              String _replace_7 = z_1.getLiteral().get(0).replace("\"", "");
              boolean _equals_1 = Objects.equals(_replace_7, "on");
              if (_equals_1) {
                _builder.newLine();
                _builder.append("<!-- EXPERIENCE -->");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_14 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "Experience"));
                  };
                  Iterable<Entity> _filter_14 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_14);
                  for(final Entity i_5 : _filter_14) {
                    {
                      EList<Feature> _features = i_5.getFeatures();
                      for(final Feature f_5 : _features) {
                        _builder.append("<div class=\"contOut clearfix\">");
                        _builder.newLine();
                        _builder.append("\t");
                        _builder.append("<div class=\"contIn\">");
                        _builder.newLine();
                        _builder.append("\t");
                        _builder.append("<div class=\"section middle clearfix\">");
                        _builder.newLine();
                        _builder.append("\t\t");
                        _builder.append("<div class=\"job\">");
                        _builder.newLine();
                        _builder.append("\t\t");
                        _builder.append("<h2>");
                        String _replace_8 = f_5.getLiteral().get(1).replace("\"", "");
                        _builder.append(_replace_8, "\t\t");
                        _builder.append("<span>");
                        String _replace_9 = f_5.getLiteral().get(2).replace("\"", "");
                        _builder.append(_replace_9, "\t\t");
                        _builder.append("</span></h2>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t");
                        _builder.append("<p><strong>Position: </strong>");
                        String _replace_10 = f_5.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_10, "\t\t");
                        _builder.append("<br/>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t");
                        _builder.append("<strong>Description: </strong>");
                        String _replace_11 = f_5.getLiteral().get(3).replace("\"", "");
                        _builder.append(_replace_11, "\t\t");
                        _builder.append("<br/>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t");
                        _builder.append("<span class=\"brag\">");
                        String _replace_12 = f_5.getLiteral().get(4).replace("\"", "");
                        _builder.append(_replace_12, "\t\t");
                        _builder.append("</span></p>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t");
                        _builder.append("</div>");
                        _builder.newLine();
                        _builder.append("\t");
                        _builder.append("</div>");
                        _builder.newLine();
                        _builder.append("\t");
                        _builder.append("<div class=\"divider\"></div>");
                        _builder.newLine();
                        _builder.append("\t");
                        _builder.append("</div>");
                        _builder.newLine();
                        _builder.append("</div>");
                        _builder.newLine();
                      }
                    }
                  }
                }
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_15 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Sections"));
      };
      Iterable<Entity> _filter_15 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_15);
      for(final Entity x_2 : _filter_15) {
        {
          final Function1<Feature, Boolean> _function_16 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "teaching"));
          };
          Iterable<Feature> _filter_16 = IterableExtensions.<Feature>filter(x_2.getFeatures(), _function_16);
          for(final Feature z_2 : _filter_16) {
            {
              String _replace_13 = z_2.getLiteral().get(0).replace("\"", "");
              boolean _equals_2 = Objects.equals(_replace_13, "on");
              if (_equals_2) {
                _builder.newLine();
                _builder.append("<!-- TEACHING -->");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_17 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "TeachingBSc"));
                  };
                  Iterable<Entity> _filter_17 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_17);
                  for(final Entity i_6 : _filter_17) {
                    _builder.append("<div class=\"contOut clearfix\">");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<div class=\"contIn\">");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<div class=\"contracts clearfix\">");
                    _builder.newLine();
                    {
                      final Function1<Feature, Boolean> _function_18 = (Feature it) -> {
                        String _name = it.getName();
                        return Boolean.valueOf(Objects.equals(_name, "intro"));
                      };
                      Iterable<Feature> _filter_18 = IterableExtensions.<Feature>filter(i_6.getFeatures(), _function_18);
                      for(final Feature f_6 : _filter_18) {
                        _builder.append("\t\t");
                        _builder.append("<h3>");
                        String _replace_14 = f_6.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_14, "\t\t");
                        _builder.append("</h3>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                    _builder.newLine();
                    {
                      final Function1<Feature, Boolean> _function_19 = (Feature it) -> {
                        String _name = it.getName();
                        return Boolean.valueOf((!Objects.equals(_name, "intro")));
                      };
                      Iterable<Feature> _filter_19 = IterableExtensions.<Feature>filter(i_6.getFeatures(), _function_19);
                      for(final Feature f_7 : _filter_19) {
                        _builder.append("\t");
                        _builder.append("<div class=\"contract\">");
                        _builder.newLine();
                        _builder.append("\t");
                        _builder.append("\t");
                        _builder.append("<h4>");
                        String _replace_15 = f_7.getLiteral().get(1).replace("\"", "");
                        _builder.append(_replace_15, "\t\t");
                        _builder.append("</h4>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t");
                        _builder.append("\t");
                        _builder.append("<p class=\"desc\">");
                        String _replace_16 = f_7.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_16, "\t\t");
                        _builder.append("</p>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t");
                        _builder.append("\t");
                        _builder.append("<span class=\"date\">");
                        String _replace_17 = f_7.getLiteral().get(2).replace("\"", "");
                        _builder.append(_replace_17, "\t\t");
                        _builder.append("</span>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t");
                        _builder.append("</div>");
                        _builder.newLine();
                      }
                    }
                    _builder.append("\t");
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.append("</div>");
                    _builder.newLine();
                  }
                }
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_20 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "TeachingMSc"));
                  };
                  Iterable<Entity> _filter_20 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_20);
                  for(final Entity i_7 : _filter_20) {
                    _builder.append("<div class=\"contOut clearfix\">");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<div class=\"contIn\">");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<div class=\"contracts clearfix\">");
                    _builder.newLine();
                    {
                      final Function1<Feature, Boolean> _function_21 = (Feature it) -> {
                        String _name = it.getName();
                        return Boolean.valueOf(Objects.equals(_name, "intro"));
                      };
                      Iterable<Feature> _filter_21 = IterableExtensions.<Feature>filter(i_7.getFeatures(), _function_21);
                      for(final Feature f_8 : _filter_21) {
                        _builder.append("\t\t");
                        _builder.append("<h3>");
                        String _replace_18 = f_8.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_18, "\t\t");
                        _builder.append("</h3>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                    _builder.newLine();
                    {
                      final Function1<Feature, Boolean> _function_22 = (Feature it) -> {
                        String _name = it.getName();
                        return Boolean.valueOf((!Objects.equals(_name, "intro")));
                      };
                      Iterable<Feature> _filter_22 = IterableExtensions.<Feature>filter(i_7.getFeatures(), _function_22);
                      for(final Feature f_9 : _filter_22) {
                        _builder.append("\t");
                        _builder.append("<div class=\"contract\">");
                        _builder.newLine();
                        _builder.append("\t");
                        _builder.append("\t");
                        _builder.append("<h4>");
                        String _replace_19 = f_9.getLiteral().get(1).replace("\"", "");
                        _builder.append(_replace_19, "\t\t");
                        _builder.append("</h4>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t");
                        _builder.append("\t");
                        _builder.append("<p class=\"desc\">");
                        String _replace_20 = f_9.getLiteral().get(0).replace("\"", "");
                        _builder.append(_replace_20, "\t\t");
                        _builder.append("</p>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t");
                        _builder.append("\t");
                        _builder.append("<span class=\"date\">");
                        String _replace_21 = f_9.getLiteral().get(2).replace("\"", "");
                        _builder.append(_replace_21, "\t\t");
                        _builder.append("</span>");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t");
                        _builder.append("</div>");
                        _builder.newLine();
                      }
                    }
                    _builder.append("\t");
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.append("</div>");
                    _builder.newLine();
                  }
                }
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_23 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Sections"));
      };
      Iterable<Entity> _filter_23 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_23);
      for(final Entity x_3 : _filter_23) {
        {
          final Function1<Feature, Boolean> _function_24 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "skills_1"));
          };
          Iterable<Feature> _filter_24 = IterableExtensions.<Feature>filter(x_3.getFeatures(), _function_24);
          for(final Feature z_3 : _filter_24) {
            {
              String _replace_22 = z_3.getLiteral().get(0).replace("\"", "");
              boolean _equals_3 = Objects.equals(_replace_22, "on");
              if (_equals_3) {
                _builder.newLine();
                _builder.append("<!-- SKILLS -->");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_25 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "Skills_Research"));
                  };
                  Iterable<Entity> _filter_25 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_25);
                  for(final Entity i_8 : _filter_25) {
                    _builder.append("<div class=\"contOut clearfix half\">");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<div class=\"contIn\">");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<div class=\"section middle clearfix\">");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("<div class=\"skills code odd\">");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("<h3>Code & Software<i class=\"fa fa-code\"></i></h3>");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("<ul>");
                    _builder.newLine();
                    _builder.newLine();
                    {
                      EList<Feature> _features_1 = i_8.getFeatures();
                      for(final Feature f_10 : _features_1) {
                        {
                          String _replace_23 = f_10.getLiteral().get(1).replace("\"", "");
                          boolean _equals_4 = Objects.equals(_replace_23, "0");
                          if (_equals_4) {
                            _builder.append("<li>");
                            String _replace_24 = f_10.getLiteral().get(0).replace("\"", "");
                            _builder.append(_replace_24);
                            _builder.append("</li>");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                        {
                          String _replace_25 = f_10.getLiteral().get(1).replace("\"", "");
                          boolean _equals_5 = Objects.equals(_replace_25, "1");
                          if (_equals_5) {
                            _builder.append("<li class=\"prim\">");
                            String _replace_26 = f_10.getLiteral().get(0).replace("\"", "");
                            _builder.append(_replace_26);
                            _builder.append("</li>");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                        {
                          String _replace_27 = f_10.getLiteral().get(1).replace("\"", "");
                          boolean _equals_6 = Objects.equals(_replace_27, "2");
                          if (_equals_6) {
                            _builder.append("<li class=\"light\">");
                            String _replace_28 = f_10.getLiteral().get(0).replace("\"", "");
                            _builder.append(_replace_28);
                            _builder.append("</li>");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("</ul>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("</div>");
                    _builder.newLine();
                  }
                }
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_26 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Sections"));
      };
      Iterable<Entity> _filter_26 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_26);
      for(final Entity x_4 : _filter_26) {
        {
          final Function1<Feature, Boolean> _function_27 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "skills_2"));
          };
          Iterable<Feature> _filter_27 = IterableExtensions.<Feature>filter(x_4.getFeatures(), _function_27);
          for(final Feature z_4 : _filter_27) {
            {
              String _replace_29 = z_4.getLiteral().get(0).replace("\"", "");
              boolean _equals_7 = Objects.equals(_replace_29, "on");
              if (_equals_7) {
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_28 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "Skills_Development"));
                  };
                  Iterable<Entity> _filter_28 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_28);
                  for(final Entity i_9 : _filter_28) {
                    _builder.append("\t\t");
                    _builder.append("<div class=\"skills software\">");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("<h3>Practices & Tools<i class=\"fa fa-laptop\"></i></h3>");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("<ul>");
                    _builder.newLine();
                    _builder.newLine();
                    {
                      EList<Feature> _features_2 = i_9.getFeatures();
                      for(final Feature f_11 : _features_2) {
                        {
                          String _replace_30 = f_11.getLiteral().get(1).replace("\"", "");
                          boolean _equals_8 = Objects.equals(_replace_30, "0");
                          if (_equals_8) {
                            _builder.append("\t");
                            _builder.append("<li>");
                            String _replace_31 = f_11.getLiteral().get(0).replace("\"", "");
                            _builder.append(_replace_31, "\t");
                            _builder.append("</li>");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                        {
                          String _replace_32 = f_11.getLiteral().get(1).replace("\"", "");
                          boolean _equals_9 = Objects.equals(_replace_32, "1");
                          if (_equals_9) {
                            _builder.append("\t");
                            _builder.append("<li class=\"prim\">");
                            String _replace_33 = f_11.getLiteral().get(0).replace("\"", "");
                            _builder.append(_replace_33, "\t");
                            _builder.append("</li>");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                        {
                          String _replace_34 = f_11.getLiteral().get(1).replace("\"", "");
                          boolean _equals_10 = Objects.equals(_replace_34, "2");
                          if (_equals_10) {
                            _builder.append("\t");
                            _builder.append("<li class=\"light\">");
                            String _replace_35 = f_11.getLiteral().get(0).replace("\"", "");
                            _builder.append(_replace_35, "\t");
                            _builder.append("</li>");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                    _builder.append("\t\t");
                    _builder.append("</ul>");
                    _builder.newLine();
                    _builder.append("\t\t");
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<div class=\"divider\"></div>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.append("</div>");
                    _builder.newLine();
                  }
                }
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function_29 = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Sections"));
      };
      Iterable<Entity> _filter_29 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_29);
      for(final Entity x_5 : _filter_29) {
        {
          final Function1<Feature, Boolean> _function_30 = (Feature it) -> {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equals(_name, "socials"));
          };
          Iterable<Feature> _filter_30 = IterableExtensions.<Feature>filter(x_5.getFeatures(), _function_30);
          for(final Feature z_5 : _filter_30) {
            {
              String _replace_36 = z_5.getLiteral().get(0).replace("\"", "");
              boolean _equals_11 = Objects.equals(_replace_36, "on");
              if (_equals_11) {
                _builder.newLine();
                _builder.append("<!-- SOCIALS -->");
                _builder.newLine();
                {
                  final Function1<Entity, Boolean> _function_31 = (Entity it) -> {
                    String _name = it.getName();
                    return Boolean.valueOf(Objects.equals(_name, "Socials"));
                  };
                  Iterable<Entity> _filter_31 = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function_31);
                  for(final Entity i_10 : _filter_31) {
                    _builder.append("<div class=\"contOut clearfix half\">");
                    _builder.newLine();
                    _builder.append("\t\t\t");
                    _builder.append("<div class=\"contIn\">");
                    _builder.newLine();
                    _builder.append("\t\t\t");
                    _builder.append("<div class=\"section middle clearfix\">");
                    _builder.newLine();
                    _builder.append("\t\t\t\t");
                    _builder.append("<ul class=\"buttons\">");
                    _builder.newLine();
                    {
                      EList<Feature> _features_3 = i_10.getFeatures();
                      for(final Feature f_12 : _features_3) {
                        _builder.append("\t");
                        _builder.append("<li><a href=");
                        String _get_1 = f_12.getLiteral().get(0);
                        _builder.append(_get_1, "\t");
                        _builder.append(" target=\"_blank\">");
                        String _name = f_12.getName();
                        _builder.append(_name, "\t");
                        _builder.append("</a></li>");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                    _builder.append("\t\t");
                    _builder.append("</ul>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("<div class=\"divider\"></div>");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("</div>");
                    _builder.newLine();
                    _builder.append("</div>");
                    _builder.newLine();
                  }
                }
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    _builder.newLine();
    _builder.append("<!-- partial -->");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<script src=\'//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js\'></script><script type=\"text/javascript\"\tsrc=\"./script.js\"></script>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("</body>");
    _builder.newLine();
    _builder.append("</html>");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }

  public CharSequence generateHtmlCode3Index(final PackageDeclaration p) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<link rel=\"stylesheet\" href=\"./style.css\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<div class=\"row\">");
    _builder.newLine();
    {
      EList<AbstractElement> _elements = p.getElements();
      for(final AbstractElement user : _elements) {
        {
          if ((user instanceof Entity)) {
            _builder.append("\t");
            _builder.append("<div class=\"column\">");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("<div class=\"card\">");
            _builder.newLine();
            {
              final Function1<Feature, Boolean> _function = (Feature it) -> {
                String _name = it.getName();
                return Boolean.valueOf(Objects.equals(_name, "id"));
              };
              Iterable<Feature> _filter = IterableExtensions.<Feature>filter(((Entity)user).getFeatures(), _function);
              for(final Feature f : _filter) {
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("<a href=\"users\\");
                String _replace = f.getLiteral().get(0).replace("\"", "");
                _builder.append(_replace, "\t\t");
                _builder.append(".html\">");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("<img src=\"..\\static\\");
                String _replace_1 = f.getLiteral().get(0).replace("\"", "");
                _builder.append(_replace_1, "\t\t\t");
                _builder.append(".png\" alt=");
                String _get = f.getLiteral().get(0);
                _builder.append(_get, "\t\t\t");
                _builder.append(" style=\"width:100%\">");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("</a>");
                _builder.newLine();
              }
            }
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("<div class=\"container\">");
            _builder.newLine();
            {
              final Function1<Feature, Boolean> _function_1 = (Feature it) -> {
                String _name = it.getName();
                return Boolean.valueOf(Objects.equals(_name, "name"));
              };
              Iterable<Feature> _filter_1 = IterableExtensions.<Feature>filter(((Entity)user).getFeatures(), _function_1);
              for(final Feature f_1 : _filter_1) {
                _builder.append("\t");
                _builder.append("\t");
                _builder.append("<h2>");
                String _replace_2 = f_1.getLiteral().get(0).replace("\"", "");
                _builder.append(_replace_2, "\t\t");
                _builder.append("</h2>");
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append("\t");
            _builder.append("\t\t\t");
            _builder.append("<p class=\"title\">CEO &amp; Founder</p>");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("\t\t\t");
            _builder.append("<p>Some text that describes me lorem ipsum ipsum lorem.</p>");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("\t\t\t");
            _builder.append("<p>example@example.com</p>");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("\t\t\t");
            _builder.append("<p><button class=\"button\">Contact</button></p>");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("\t  \t");
            _builder.append("</div>");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("</div>");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("</div>");
            _builder.newLine();
            _builder.append("\t");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("</div>");
    _builder.newLine();
    return _builder;
  }

  public CharSequence generateHtmlCode3User(final Entity e) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<!-- Add icon library -->");
    _builder.newLine();
    _builder.append("<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">");
    _builder.newLine();
    _builder.append("<link rel=\"stylesheet\" href=\"./style.css\">");
    _builder.newLine();
    _builder.newLine();
    _builder.newLine();
    _builder.append("All features");
    _builder.newLine();
    {
      EList<Feature> _features = e.getFeatures();
      for(final Feature f : _features) {
        String _name = f.getName();
        _builder.append(_name);
        _builder.append(" - ");
        String _get = f.getLiteral().get(0);
        _builder.append(_get);
        _builder.append(" <br>");
        _builder.newLineIfNotEmpty();
        String _name_1 = f.getName();
        _builder.append(_name_1);
        _builder.append(" - ");
        String _replace = f.getLiteral().get(0).replace("\"", "");
        _builder.append(_replace);
        _builder.append("<br>");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("Filter a single one<br>");
    _builder.newLine();
    {
      final Function1<Feature, Boolean> _function = (Feature it) -> {
        String _name_2 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_2, "tlfn"));
      };
      Iterable<Feature> _filter = IterableExtensions.<Feature>filter(e.getFeatures(), _function);
      for(final Feature f_1 : _filter) {
        String _name_2 = f_1.getName();
        _builder.append(_name_2);
        _builder.append(" - ");
        String _get_1 = f_1.getLiteral().get(0);
        _builder.append(_get_1);
        _builder.append("<br>");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("You need to:<br>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("Use name for the static picture file<br>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("Name<br>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("Position<br>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("Location (UAM)<br>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("4 links (linkedin, twitter, github, scholar?)<br>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("Finish the contact button - put mail on it<br>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<div class=\"card\">");
    _builder.newLine();
    {
      final Function1<Feature, Boolean> _function_1 = (Feature it) -> {
        String _name_3 = it.getName();
        return Boolean.valueOf(Objects.equals(_name_3, "id"));
      };
      Iterable<Feature> _filter_1 = IterableExtensions.<Feature>filter(e.getFeatures(), _function_1);
      for(final Feature f_2 : _filter_1) {
        _builder.append("<img src=\"..\\..\\static\\");
        String _replace_1 = f_2.getLiteral().get(0).replace("\"", "");
        _builder.append(_replace_1);
        _builder.append(".png\" alt=");
        String _get_2 = f_2.getLiteral().get(0);
        _builder.append(_get_2);
        _builder.append(" style=\"width:100%\">");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("  ");
    _builder.append("<h1>John Doe</h1>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<p class=\"title\">CEO & Founder, Example</p>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<p>Universidad autónoma de Madrid</p>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<a href=\"#\"><i class=\"fa fa-dribbble\"></i></a>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<a href=\"#\"><i class=\"fa fa-twitter\"></i></a>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<a href=\"#\"><i class=\"fa fa-linkedin\"></i></a>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<a href=\"#\"><i class=\"fa fa-facebook\"></i></a>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<p><button>Contact</button></p>");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<script>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("function goBack() {");
    _builder.newLine();
    _builder.append("\t  ");
    _builder.append("window.history.back()");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("</script>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<p>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<button onclick=\"goBack()\">Return</button>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("</p>");
    _builder.newLine();
    _builder.append("</div> ");
    _builder.newLine();
    return _builder;
  }

  public CharSequence generateHtmlCodeDEBUG(final Entity... e) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<!DOCTYPE html>");
    _builder.newLine();
    _builder.append("<html lang=\"en\" >");
    _builder.newLine();
    {
      final Function1<Entity, Boolean> _function = (Entity it) -> {
        String _name = it.getName();
        return Boolean.valueOf(Objects.equals(_name, "Template"));
      };
      Iterable<Entity> _filter = IterableExtensions.<Entity>filter(((Iterable<Entity>)Conversions.doWrapArray(e)), _function);
      for(final Entity i : _filter) {
        {
          EList<Feature> _features = i.getFeatures();
          for(final Feature f : _features) {
            _builder.append("FEATURE ");
            String _name = f.getName();
            _builder.append(_name);
            _builder.append(" = ");
            String _get = f.getLiteral().get(0);
            _builder.append(_get);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("<br>");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
}
