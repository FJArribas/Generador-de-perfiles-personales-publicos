package org.tfg.blog.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.tfg.blog.services.MyBlogGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyBlogParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'package'", "'{'", "'}'", "'datatype'", "'entity'", "'extends'", "','", "'single'", "'many'", "':'"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=6;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__20=20;

    // delegates
    // delegators


        public InternalMyBlogParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyBlogParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyBlogParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyBlog.g"; }



     	private MyBlogGrammarAccess grammarAccess;

        public InternalMyBlogParser(TokenStream input, MyBlogGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Domainmodel";
       	}

       	@Override
       	protected MyBlogGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleDomainmodel"
    // InternalMyBlog.g:64:1: entryRuleDomainmodel returns [EObject current=null] : iv_ruleDomainmodel= ruleDomainmodel EOF ;
    public final EObject entryRuleDomainmodel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDomainmodel = null;


        try {
            // InternalMyBlog.g:64:52: (iv_ruleDomainmodel= ruleDomainmodel EOF )
            // InternalMyBlog.g:65:2: iv_ruleDomainmodel= ruleDomainmodel EOF
            {
             newCompositeNode(grammarAccess.getDomainmodelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDomainmodel=ruleDomainmodel();

            state._fsp--;

             current =iv_ruleDomainmodel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDomainmodel"


    // $ANTLR start "ruleDomainmodel"
    // InternalMyBlog.g:71:1: ruleDomainmodel returns [EObject current=null] : ( (lv_elements_0_0= ruleAbstractElement ) )* ;
    public final EObject ruleDomainmodel() throws RecognitionException {
        EObject current = null;

        EObject lv_elements_0_0 = null;



        	enterRule();

        try {
            // InternalMyBlog.g:77:2: ( ( (lv_elements_0_0= ruleAbstractElement ) )* )
            // InternalMyBlog.g:78:2: ( (lv_elements_0_0= ruleAbstractElement ) )*
            {
            // InternalMyBlog.g:78:2: ( (lv_elements_0_0= ruleAbstractElement ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11||(LA1_0>=14 && LA1_0<=15)||LA1_0==18) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalMyBlog.g:79:3: (lv_elements_0_0= ruleAbstractElement )
            	    {
            	    // InternalMyBlog.g:79:3: (lv_elements_0_0= ruleAbstractElement )
            	    // InternalMyBlog.g:80:4: lv_elements_0_0= ruleAbstractElement
            	    {

            	    				newCompositeNode(grammarAccess.getDomainmodelAccess().getElementsAbstractElementParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_elements_0_0=ruleAbstractElement();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getDomainmodelRule());
            	    				}
            	    				add(
            	    					current,
            	    					"elements",
            	    					lv_elements_0_0,
            	    					"org.tfg.blog.MyBlog.AbstractElement");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDomainmodel"


    // $ANTLR start "entryRulePackageDeclaration"
    // InternalMyBlog.g:100:1: entryRulePackageDeclaration returns [EObject current=null] : iv_rulePackageDeclaration= rulePackageDeclaration EOF ;
    public final EObject entryRulePackageDeclaration() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePackageDeclaration = null;


        try {
            // InternalMyBlog.g:100:59: (iv_rulePackageDeclaration= rulePackageDeclaration EOF )
            // InternalMyBlog.g:101:2: iv_rulePackageDeclaration= rulePackageDeclaration EOF
            {
             newCompositeNode(grammarAccess.getPackageDeclarationRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePackageDeclaration=rulePackageDeclaration();

            state._fsp--;

             current =iv_rulePackageDeclaration; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePackageDeclaration"


    // $ANTLR start "rulePackageDeclaration"
    // InternalMyBlog.g:107:1: rulePackageDeclaration returns [EObject current=null] : (otherlv_0= 'package' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleAbstractElement ) )* otherlv_4= '}' ) ;
    public final EObject rulePackageDeclaration() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_elements_3_0 = null;



        	enterRule();

        try {
            // InternalMyBlog.g:113:2: ( (otherlv_0= 'package' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleAbstractElement ) )* otherlv_4= '}' ) )
            // InternalMyBlog.g:114:2: (otherlv_0= 'package' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleAbstractElement ) )* otherlv_4= '}' )
            {
            // InternalMyBlog.g:114:2: (otherlv_0= 'package' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleAbstractElement ) )* otherlv_4= '}' )
            // InternalMyBlog.g:115:3: otherlv_0= 'package' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleAbstractElement ) )* otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getPackageDeclarationAccess().getPackageKeyword_0());
            		
            // InternalMyBlog.g:119:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalMyBlog.g:120:4: (lv_name_1_0= RULE_ID )
            {
            // InternalMyBlog.g:120:4: (lv_name_1_0= RULE_ID )
            // InternalMyBlog.g:121:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getPackageDeclarationAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPackageDeclarationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getPackageDeclarationAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyBlog.g:141:3: ( (lv_elements_3_0= ruleAbstractElement ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==11||(LA2_0>=14 && LA2_0<=15)||LA2_0==18) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalMyBlog.g:142:4: (lv_elements_3_0= ruleAbstractElement )
            	    {
            	    // InternalMyBlog.g:142:4: (lv_elements_3_0= ruleAbstractElement )
            	    // InternalMyBlog.g:143:5: lv_elements_3_0= ruleAbstractElement
            	    {

            	    					newCompositeNode(grammarAccess.getPackageDeclarationAccess().getElementsAbstractElementParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_6);
            	    lv_elements_3_0=ruleAbstractElement();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getPackageDeclarationRule());
            	    					}
            	    					add(
            	    						current,
            	    						"elements",
            	    						lv_elements_3_0,
            	    						"org.tfg.blog.MyBlog.AbstractElement");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            otherlv_4=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getPackageDeclarationAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePackageDeclaration"


    // $ANTLR start "entryRuleAbstractElement"
    // InternalMyBlog.g:168:1: entryRuleAbstractElement returns [EObject current=null] : iv_ruleAbstractElement= ruleAbstractElement EOF ;
    public final EObject entryRuleAbstractElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAbstractElement = null;


        try {
            // InternalMyBlog.g:168:56: (iv_ruleAbstractElement= ruleAbstractElement EOF )
            // InternalMyBlog.g:169:2: iv_ruleAbstractElement= ruleAbstractElement EOF
            {
             newCompositeNode(grammarAccess.getAbstractElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAbstractElement=ruleAbstractElement();

            state._fsp--;

             current =iv_ruleAbstractElement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAbstractElement"


    // $ANTLR start "ruleAbstractElement"
    // InternalMyBlog.g:175:1: ruleAbstractElement returns [EObject current=null] : (this_PackageDeclaration_0= rulePackageDeclaration | this_Type_1= ruleType ) ;
    public final EObject ruleAbstractElement() throws RecognitionException {
        EObject current = null;

        EObject this_PackageDeclaration_0 = null;

        EObject this_Type_1 = null;



        	enterRule();

        try {
            // InternalMyBlog.g:181:2: ( (this_PackageDeclaration_0= rulePackageDeclaration | this_Type_1= ruleType ) )
            // InternalMyBlog.g:182:2: (this_PackageDeclaration_0= rulePackageDeclaration | this_Type_1= ruleType )
            {
            // InternalMyBlog.g:182:2: (this_PackageDeclaration_0= rulePackageDeclaration | this_Type_1= ruleType )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==11) ) {
                alt3=1;
            }
            else if ( ((LA3_0>=14 && LA3_0<=15)||LA3_0==18) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalMyBlog.g:183:3: this_PackageDeclaration_0= rulePackageDeclaration
                    {

                    			newCompositeNode(grammarAccess.getAbstractElementAccess().getPackageDeclarationParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_PackageDeclaration_0=rulePackageDeclaration();

                    state._fsp--;


                    			current = this_PackageDeclaration_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMyBlog.g:192:3: this_Type_1= ruleType
                    {

                    			newCompositeNode(grammarAccess.getAbstractElementAccess().getTypeParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Type_1=ruleType();

                    state._fsp--;


                    			current = this_Type_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAbstractElement"


    // $ANTLR start "entryRuleType"
    // InternalMyBlog.g:204:1: entryRuleType returns [EObject current=null] : iv_ruleType= ruleType EOF ;
    public final EObject entryRuleType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleType = null;


        try {
            // InternalMyBlog.g:204:45: (iv_ruleType= ruleType EOF )
            // InternalMyBlog.g:205:2: iv_ruleType= ruleType EOF
            {
             newCompositeNode(grammarAccess.getTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleType=ruleType();

            state._fsp--;

             current =iv_ruleType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleType"


    // $ANTLR start "ruleType"
    // InternalMyBlog.g:211:1: ruleType returns [EObject current=null] : (this_DataType_0= ruleDataType | this_Entity_1= ruleEntity | this_SingleEntity_2= ruleSingleEntity ) ;
    public final EObject ruleType() throws RecognitionException {
        EObject current = null;

        EObject this_DataType_0 = null;

        EObject this_Entity_1 = null;

        EObject this_SingleEntity_2 = null;



        	enterRule();

        try {
            // InternalMyBlog.g:217:2: ( (this_DataType_0= ruleDataType | this_Entity_1= ruleEntity | this_SingleEntity_2= ruleSingleEntity ) )
            // InternalMyBlog.g:218:2: (this_DataType_0= ruleDataType | this_Entity_1= ruleEntity | this_SingleEntity_2= ruleSingleEntity )
            {
            // InternalMyBlog.g:218:2: (this_DataType_0= ruleDataType | this_Entity_1= ruleEntity | this_SingleEntity_2= ruleSingleEntity )
            int alt4=3;
            switch ( input.LA(1) ) {
            case 14:
                {
                alt4=1;
                }
                break;
            case 15:
                {
                alt4=2;
                }
                break;
            case 18:
                {
                alt4=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // InternalMyBlog.g:219:3: this_DataType_0= ruleDataType
                    {

                    			newCompositeNode(grammarAccess.getTypeAccess().getDataTypeParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_DataType_0=ruleDataType();

                    state._fsp--;


                    			current = this_DataType_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMyBlog.g:228:3: this_Entity_1= ruleEntity
                    {

                    			newCompositeNode(grammarAccess.getTypeAccess().getEntityParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Entity_1=ruleEntity();

                    state._fsp--;


                    			current = this_Entity_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMyBlog.g:237:3: this_SingleEntity_2= ruleSingleEntity
                    {

                    			newCompositeNode(grammarAccess.getTypeAccess().getSingleEntityParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_SingleEntity_2=ruleSingleEntity();

                    state._fsp--;


                    			current = this_SingleEntity_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleType"


    // $ANTLR start "entryRuleDataType"
    // InternalMyBlog.g:249:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalMyBlog.g:249:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalMyBlog.g:250:2: iv_ruleDataType= ruleDataType EOF
            {
             newCompositeNode(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;

             current =iv_ruleDataType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalMyBlog.g:256:1: ruleDataType returns [EObject current=null] : (otherlv_0= 'datatype' ( (lv_name_1_0= RULE_ID ) ) ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;


        	enterRule();

        try {
            // InternalMyBlog.g:262:2: ( (otherlv_0= 'datatype' ( (lv_name_1_0= RULE_ID ) ) ) )
            // InternalMyBlog.g:263:2: (otherlv_0= 'datatype' ( (lv_name_1_0= RULE_ID ) ) )
            {
            // InternalMyBlog.g:263:2: (otherlv_0= 'datatype' ( (lv_name_1_0= RULE_ID ) ) )
            // InternalMyBlog.g:264:3: otherlv_0= 'datatype' ( (lv_name_1_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,14,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getDataTypeAccess().getDatatypeKeyword_0());
            		
            // InternalMyBlog.g:268:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalMyBlog.g:269:4: (lv_name_1_0= RULE_ID )
            {
            // InternalMyBlog.g:269:4: (lv_name_1_0= RULE_ID )
            // InternalMyBlog.g:270:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_name_1_0, grammarAccess.getDataTypeAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDataTypeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleEntity"
    // InternalMyBlog.g:290:1: entryRuleEntity returns [EObject current=null] : iv_ruleEntity= ruleEntity EOF ;
    public final EObject entryRuleEntity() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEntity = null;


        try {
            // InternalMyBlog.g:290:47: (iv_ruleEntity= ruleEntity EOF )
            // InternalMyBlog.g:291:2: iv_ruleEntity= ruleEntity EOF
            {
             newCompositeNode(grammarAccess.getEntityRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEntity=ruleEntity();

            state._fsp--;

             current =iv_ruleEntity; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEntity"


    // $ANTLR start "ruleEntity"
    // InternalMyBlog.g:297:1: ruleEntity returns [EObject current=null] : (otherlv_0= 'entity' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '{' ( (lv_features_5_0= ruleFeature ) ) (otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) ) )* otherlv_8= '}' ) ;
    public final EObject ruleEntity() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        EObject lv_features_5_0 = null;

        EObject lv_features_7_0 = null;



        	enterRule();

        try {
            // InternalMyBlog.g:303:2: ( (otherlv_0= 'entity' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '{' ( (lv_features_5_0= ruleFeature ) ) (otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) ) )* otherlv_8= '}' ) )
            // InternalMyBlog.g:304:2: (otherlv_0= 'entity' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '{' ( (lv_features_5_0= ruleFeature ) ) (otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) ) )* otherlv_8= '}' )
            {
            // InternalMyBlog.g:304:2: (otherlv_0= 'entity' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '{' ( (lv_features_5_0= ruleFeature ) ) (otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) ) )* otherlv_8= '}' )
            // InternalMyBlog.g:305:3: otherlv_0= 'entity' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '{' ( (lv_features_5_0= ruleFeature ) ) (otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) ) )* otherlv_8= '}'
            {
            otherlv_0=(Token)match(input,15,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getEntityAccess().getEntityKeyword_0());
            		
            // InternalMyBlog.g:309:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalMyBlog.g:310:4: (lv_name_1_0= RULE_ID )
            {
            // InternalMyBlog.g:310:4: (lv_name_1_0= RULE_ID )
            // InternalMyBlog.g:311:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_7); 

            					newLeafNode(lv_name_1_0, grammarAccess.getEntityAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEntityRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalMyBlog.g:327:3: (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==16) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalMyBlog.g:328:4: otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,16,FOLLOW_4); 

                    				newLeafNode(otherlv_2, grammarAccess.getEntityAccess().getExtendsKeyword_2_0());
                    			
                    // InternalMyBlog.g:332:4: ( (otherlv_3= RULE_ID ) )
                    // InternalMyBlog.g:333:5: (otherlv_3= RULE_ID )
                    {
                    // InternalMyBlog.g:333:5: (otherlv_3= RULE_ID )
                    // InternalMyBlog.g:334:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getEntityRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_5); 

                    						newLeafNode(otherlv_3, grammarAccess.getEntityAccess().getSuperTypeEntityCrossReference_2_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_4=(Token)match(input,12,FOLLOW_8); 

            			newLeafNode(otherlv_4, grammarAccess.getEntityAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalMyBlog.g:350:3: ( (lv_features_5_0= ruleFeature ) )
            // InternalMyBlog.g:351:4: (lv_features_5_0= ruleFeature )
            {
            // InternalMyBlog.g:351:4: (lv_features_5_0= ruleFeature )
            // InternalMyBlog.g:352:5: lv_features_5_0= ruleFeature
            {

            					newCompositeNode(grammarAccess.getEntityAccess().getFeaturesFeatureParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_9);
            lv_features_5_0=ruleFeature();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getEntityRule());
            					}
            					add(
            						current,
            						"features",
            						lv_features_5_0,
            						"org.tfg.blog.MyBlog.Feature");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyBlog.g:369:3: (otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==17) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalMyBlog.g:370:4: otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) )
            	    {
            	    otherlv_6=(Token)match(input,17,FOLLOW_8); 

            	    				newLeafNode(otherlv_6, grammarAccess.getEntityAccess().getCommaKeyword_5_0());
            	    			
            	    // InternalMyBlog.g:374:4: ( (lv_features_7_0= ruleFeature ) )
            	    // InternalMyBlog.g:375:5: (lv_features_7_0= ruleFeature )
            	    {
            	    // InternalMyBlog.g:375:5: (lv_features_7_0= ruleFeature )
            	    // InternalMyBlog.g:376:6: lv_features_7_0= ruleFeature
            	    {

            	    						newCompositeNode(grammarAccess.getEntityAccess().getFeaturesFeatureParserRuleCall_5_1_0());
            	    					
            	    pushFollow(FOLLOW_9);
            	    lv_features_7_0=ruleFeature();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getEntityRule());
            	    						}
            	    						add(
            	    							current,
            	    							"features",
            	    							lv_features_7_0,
            	    							"org.tfg.blog.MyBlog.Feature");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            otherlv_8=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getEntityAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEntity"


    // $ANTLR start "entryRuleSingleEntity"
    // InternalMyBlog.g:402:1: entryRuleSingleEntity returns [EObject current=null] : iv_ruleSingleEntity= ruleSingleEntity EOF ;
    public final EObject entryRuleSingleEntity() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSingleEntity = null;


        try {
            // InternalMyBlog.g:402:53: (iv_ruleSingleEntity= ruleSingleEntity EOF )
            // InternalMyBlog.g:403:2: iv_ruleSingleEntity= ruleSingleEntity EOF
            {
             newCompositeNode(grammarAccess.getSingleEntityRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSingleEntity=ruleSingleEntity();

            state._fsp--;

             current =iv_ruleSingleEntity; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSingleEntity"


    // $ANTLR start "ruleSingleEntity"
    // InternalMyBlog.g:409:1: ruleSingleEntity returns [EObject current=null] : (otherlv_0= 'single' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '{' ( (lv_features_5_0= ruleFeature ) ) (otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) ) )? otherlv_8= '}' ) ;
    public final EObject ruleSingleEntity() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        EObject lv_features_5_0 = null;

        EObject lv_features_7_0 = null;



        	enterRule();

        try {
            // InternalMyBlog.g:415:2: ( (otherlv_0= 'single' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '{' ( (lv_features_5_0= ruleFeature ) ) (otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) ) )? otherlv_8= '}' ) )
            // InternalMyBlog.g:416:2: (otherlv_0= 'single' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '{' ( (lv_features_5_0= ruleFeature ) ) (otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) ) )? otherlv_8= '}' )
            {
            // InternalMyBlog.g:416:2: (otherlv_0= 'single' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '{' ( (lv_features_5_0= ruleFeature ) ) (otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) ) )? otherlv_8= '}' )
            // InternalMyBlog.g:417:3: otherlv_0= 'single' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '{' ( (lv_features_5_0= ruleFeature ) ) (otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) ) )? otherlv_8= '}'
            {
            otherlv_0=(Token)match(input,18,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getSingleEntityAccess().getSingleKeyword_0());
            		
            // InternalMyBlog.g:421:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalMyBlog.g:422:4: (lv_name_1_0= RULE_ID )
            {
            // InternalMyBlog.g:422:4: (lv_name_1_0= RULE_ID )
            // InternalMyBlog.g:423:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_7); 

            					newLeafNode(lv_name_1_0, grammarAccess.getSingleEntityAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSingleEntityRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalMyBlog.g:439:3: (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==16) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalMyBlog.g:440:4: otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,16,FOLLOW_4); 

                    				newLeafNode(otherlv_2, grammarAccess.getSingleEntityAccess().getExtendsKeyword_2_0());
                    			
                    // InternalMyBlog.g:444:4: ( (otherlv_3= RULE_ID ) )
                    // InternalMyBlog.g:445:5: (otherlv_3= RULE_ID )
                    {
                    // InternalMyBlog.g:445:5: (otherlv_3= RULE_ID )
                    // InternalMyBlog.g:446:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSingleEntityRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_5); 

                    						newLeafNode(otherlv_3, grammarAccess.getSingleEntityAccess().getSuperTypeEntityCrossReference_2_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_4=(Token)match(input,12,FOLLOW_8); 

            			newLeafNode(otherlv_4, grammarAccess.getSingleEntityAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalMyBlog.g:462:3: ( (lv_features_5_0= ruleFeature ) )
            // InternalMyBlog.g:463:4: (lv_features_5_0= ruleFeature )
            {
            // InternalMyBlog.g:463:4: (lv_features_5_0= ruleFeature )
            // InternalMyBlog.g:464:5: lv_features_5_0= ruleFeature
            {

            					newCompositeNode(grammarAccess.getSingleEntityAccess().getFeaturesFeatureParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_9);
            lv_features_5_0=ruleFeature();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSingleEntityRule());
            					}
            					add(
            						current,
            						"features",
            						lv_features_5_0,
            						"org.tfg.blog.MyBlog.Feature");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyBlog.g:481:3: (otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==17) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalMyBlog.g:482:4: otherlv_6= ',' ( (lv_features_7_0= ruleFeature ) )
                    {
                    otherlv_6=(Token)match(input,17,FOLLOW_8); 

                    				newLeafNode(otherlv_6, grammarAccess.getSingleEntityAccess().getCommaKeyword_5_0());
                    			
                    // InternalMyBlog.g:486:4: ( (lv_features_7_0= ruleFeature ) )
                    // InternalMyBlog.g:487:5: (lv_features_7_0= ruleFeature )
                    {
                    // InternalMyBlog.g:487:5: (lv_features_7_0= ruleFeature )
                    // InternalMyBlog.g:488:6: lv_features_7_0= ruleFeature
                    {

                    						newCompositeNode(grammarAccess.getSingleEntityAccess().getFeaturesFeatureParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_10);
                    lv_features_7_0=ruleFeature();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSingleEntityRule());
                    						}
                    						add(
                    							current,
                    							"features",
                    							lv_features_7_0,
                    							"org.tfg.blog.MyBlog.Feature");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_8=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getSingleEntityAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingleEntity"


    // $ANTLR start "entryRuleFeature"
    // InternalMyBlog.g:514:1: entryRuleFeature returns [EObject current=null] : iv_ruleFeature= ruleFeature EOF ;
    public final EObject entryRuleFeature() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeature = null;


        try {
            // InternalMyBlog.g:514:48: (iv_ruleFeature= ruleFeature EOF )
            // InternalMyBlog.g:515:2: iv_ruleFeature= ruleFeature EOF
            {
             newCompositeNode(grammarAccess.getFeatureRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFeature=ruleFeature();

            state._fsp--;

             current =iv_ruleFeature; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFeature"


    // $ANTLR start "ruleFeature"
    // InternalMyBlog.g:521:1: ruleFeature returns [EObject current=null] : ( ( (lv_many_0_0= 'many' ) )? ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( ( (otherlv_3= RULE_ID ) ) | ( ( (lv_literal_4_0= ruleEString ) ) (otherlv_5= ',' ( (lv_literal_6_0= ruleEString ) ) )* ) ) ) ;
    public final EObject ruleFeature() throws RecognitionException {
        EObject current = null;

        Token lv_many_0_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        AntlrDatatypeRuleToken lv_literal_4_0 = null;

        AntlrDatatypeRuleToken lv_literal_6_0 = null;



        	enterRule();

        try {
            // InternalMyBlog.g:527:2: ( ( ( (lv_many_0_0= 'many' ) )? ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( ( (otherlv_3= RULE_ID ) ) | ( ( (lv_literal_4_0= ruleEString ) ) (otherlv_5= ',' ( (lv_literal_6_0= ruleEString ) ) )* ) ) ) )
            // InternalMyBlog.g:528:2: ( ( (lv_many_0_0= 'many' ) )? ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( ( (otherlv_3= RULE_ID ) ) | ( ( (lv_literal_4_0= ruleEString ) ) (otherlv_5= ',' ( (lv_literal_6_0= ruleEString ) ) )* ) ) )
            {
            // InternalMyBlog.g:528:2: ( ( (lv_many_0_0= 'many' ) )? ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( ( (otherlv_3= RULE_ID ) ) | ( ( (lv_literal_4_0= ruleEString ) ) (otherlv_5= ',' ( (lv_literal_6_0= ruleEString ) ) )* ) ) )
            // InternalMyBlog.g:529:3: ( (lv_many_0_0= 'many' ) )? ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( ( (otherlv_3= RULE_ID ) ) | ( ( (lv_literal_4_0= ruleEString ) ) (otherlv_5= ',' ( (lv_literal_6_0= ruleEString ) ) )* ) )
            {
            // InternalMyBlog.g:529:3: ( (lv_many_0_0= 'many' ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==19) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalMyBlog.g:530:4: (lv_many_0_0= 'many' )
                    {
                    // InternalMyBlog.g:530:4: (lv_many_0_0= 'many' )
                    // InternalMyBlog.g:531:5: lv_many_0_0= 'many'
                    {
                    lv_many_0_0=(Token)match(input,19,FOLLOW_4); 

                    					newLeafNode(lv_many_0_0, grammarAccess.getFeatureAccess().getManyManyKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getFeatureRule());
                    					}
                    					setWithLastConsumed(current, "many", lv_many_0_0 != null, "many");
                    				

                    }


                    }
                    break;

            }

            // InternalMyBlog.g:543:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalMyBlog.g:544:4: (lv_name_1_0= RULE_ID )
            {
            // InternalMyBlog.g:544:4: (lv_name_1_0= RULE_ID )
            // InternalMyBlog.g:545:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_11); 

            					newLeafNode(lv_name_1_0, grammarAccess.getFeatureAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,20,FOLLOW_12); 

            			newLeafNode(otherlv_2, grammarAccess.getFeatureAccess().getColonKeyword_2());
            		
            // InternalMyBlog.g:565:3: ( ( (otherlv_3= RULE_ID ) ) | ( ( (lv_literal_4_0= ruleEString ) ) (otherlv_5= ',' ( (lv_literal_6_0= ruleEString ) ) )* ) )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==RULE_ID) ) {
                alt11=1;
            }
            else if ( (LA11_0==RULE_STRING) ) {
                alt11=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalMyBlog.g:566:4: ( (otherlv_3= RULE_ID ) )
                    {
                    // InternalMyBlog.g:566:4: ( (otherlv_3= RULE_ID ) )
                    // InternalMyBlog.g:567:5: (otherlv_3= RULE_ID )
                    {
                    // InternalMyBlog.g:567:5: (otherlv_3= RULE_ID )
                    // InternalMyBlog.g:568:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getFeatureRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_2); 

                    						newLeafNode(otherlv_3, grammarAccess.getFeatureAccess().getTypeTypeCrossReference_3_0_0());
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyBlog.g:580:4: ( ( (lv_literal_4_0= ruleEString ) ) (otherlv_5= ',' ( (lv_literal_6_0= ruleEString ) ) )* )
                    {
                    // InternalMyBlog.g:580:4: ( ( (lv_literal_4_0= ruleEString ) ) (otherlv_5= ',' ( (lv_literal_6_0= ruleEString ) ) )* )
                    // InternalMyBlog.g:581:5: ( (lv_literal_4_0= ruleEString ) ) (otherlv_5= ',' ( (lv_literal_6_0= ruleEString ) ) )*
                    {
                    // InternalMyBlog.g:581:5: ( (lv_literal_4_0= ruleEString ) )
                    // InternalMyBlog.g:582:6: (lv_literal_4_0= ruleEString )
                    {
                    // InternalMyBlog.g:582:6: (lv_literal_4_0= ruleEString )
                    // InternalMyBlog.g:583:7: lv_literal_4_0= ruleEString
                    {

                    							newCompositeNode(grammarAccess.getFeatureAccess().getLiteralEStringParserRuleCall_3_1_0_0());
                    						
                    pushFollow(FOLLOW_13);
                    lv_literal_4_0=ruleEString();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getFeatureRule());
                    							}
                    							add(
                    								current,
                    								"literal",
                    								lv_literal_4_0,
                    								"org.tfg.blog.MyBlog.EString");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    // InternalMyBlog.g:600:5: (otherlv_5= ',' ( (lv_literal_6_0= ruleEString ) ) )*
                    loop10:
                    do {
                        int alt10=2;
                        int LA10_0 = input.LA(1);

                        if ( (LA10_0==17) ) {
                            int LA10_1 = input.LA(2);

                            if ( (LA10_1==RULE_ID) ) {
                                int LA10_3 = input.LA(3);

                                if ( (LA10_3==EOF||LA10_3==13||LA10_3==17) ) {
                                    alt10=1;
                                }


                            }
                            else if ( (LA10_1==RULE_STRING) ) {
                                alt10=1;
                            }


                        }


                        switch (alt10) {
                    	case 1 :
                    	    // InternalMyBlog.g:601:6: otherlv_5= ',' ( (lv_literal_6_0= ruleEString ) )
                    	    {
                    	    otherlv_5=(Token)match(input,17,FOLLOW_12); 

                    	    						newLeafNode(otherlv_5, grammarAccess.getFeatureAccess().getCommaKeyword_3_1_1_0());
                    	    					
                    	    // InternalMyBlog.g:605:6: ( (lv_literal_6_0= ruleEString ) )
                    	    // InternalMyBlog.g:606:7: (lv_literal_6_0= ruleEString )
                    	    {
                    	    // InternalMyBlog.g:606:7: (lv_literal_6_0= ruleEString )
                    	    // InternalMyBlog.g:607:8: lv_literal_6_0= ruleEString
                    	    {

                    	    								newCompositeNode(grammarAccess.getFeatureAccess().getLiteralEStringParserRuleCall_3_1_1_1_0());
                    	    							
                    	    pushFollow(FOLLOW_13);
                    	    lv_literal_6_0=ruleEString();

                    	    state._fsp--;


                    	    								if (current==null) {
                    	    									current = createModelElementForParent(grammarAccess.getFeatureRule());
                    	    								}
                    	    								add(
                    	    									current,
                    	    									"literal",
                    	    									lv_literal_6_0,
                    	    									"org.tfg.blog.MyBlog.EString");
                    	    								afterParserOrEnumRuleCall();
                    	    							

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop10;
                        }
                    } while (true);


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFeature"


    // $ANTLR start "entryRuleEString"
    // InternalMyBlog.g:631:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalMyBlog.g:631:47: (iv_ruleEString= ruleEString EOF )
            // InternalMyBlog.g:632:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMyBlog.g:638:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalMyBlog.g:644:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalMyBlog.g:645:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalMyBlog.g:645:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==RULE_STRING) ) {
                alt12=1;
            }
            else if ( (LA12_0==RULE_ID) ) {
                alt12=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // InternalMyBlog.g:646:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMyBlog.g:654:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x000000000004C802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x000000000004E800L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000011000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000080010L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000022000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000020002L});

}